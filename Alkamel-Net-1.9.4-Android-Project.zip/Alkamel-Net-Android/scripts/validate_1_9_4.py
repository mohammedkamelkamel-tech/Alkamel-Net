from pathlib import Path
import re,sys
r=Path(__file__).resolve().parents[1]
g=(r/"app/build.gradle.kts").read_text(); k=(r/"app/src/main/java/com/alkamel/network/MainActivity.kt").read_text(); h=(r/"app/src/main/assets/home.html").read_text()
checks={
"versionName 1.9.4":'versionName = "1.9.4"' in g,
"versionCode 78":'versionCode = 78' in g,
"WebView native image chooser": "onShowFileChooser" in k and "ACTION_OPEN_DOCUMENT" in k,
"image chooser callback result": "pendingImageFileCallback?.onReceiveValue" in k and "imagePickerRequestCode" in k,
"stable seat identity matches native chat ID": "getChatDeviceId" in k and "AndroidBridge.getChatDeviceId" in h,
"speaking activity matches sender ID": "seat.id===sender" in h,
"speaking pulse expiry": "voiceActivity.delete(sender)" in h,
"seat heartbeat and reannouncement": "sendVoiceSeatEvent('join',selectedVoiceSeat)" in h,
"seat stale-state cleanup": "now-seat.lastSeen>25000" in h,
"profile image compression and persistence": "PROFILE_PHOTO_KEY,data" in h and "toDataURL('image/jpeg'" in h,
}
for n,ok in checks.items(): print(("PASS" if ok else "FAIL")+" - "+n)
print(f"\n{sum(checks.values())}/{len(checks)} checks passed")
sys.exit(0 if all(checks.values()) else 1)
