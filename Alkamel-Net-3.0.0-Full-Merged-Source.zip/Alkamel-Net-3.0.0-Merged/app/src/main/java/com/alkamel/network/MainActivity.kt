package com.alkamel.network

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.AudioManager
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.media.AudioAttributes
import android.net.wifi.WifiManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Network
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.content.pm.PackageManager
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.text.InputType
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException
import java.net.SocketException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var commandWeb: WebView? = null
    private var commandPageReady = false
    private var pendingCommand: Pair<String, String?>? = null
    private var commandAttemptInProgress = false
    private var pendingCommandAttempts = 0
    private lateinit var root: FrameLayout
    private lateinit var loading: LinearLayout
    private lateinit var errorPanel: LinearLayout
    private lateinit var customViewContainer: FrameLayout
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private val io = Executors.newSingleThreadExecutor()
    private val homeUrl = "https://appassets.androidplatform.net/assets/googleai/index.html"
    private val originalPortalUrl = "https://appassets.androidplatform.net/assets/home.html"
    @Volatile private var lastHomeUrl = homeUrl
    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }
    private val refreshInProgress = AtomicBoolean(false)
    private val networkGuard = Executors.newSingleThreadScheduledExecutor()
    @Volatile private var networkGuardStarted = false
    @Volatile private var networkAccessBlocked = true
    private var networkFailureCount = 0
    private var networkSuccessCount = 0
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var pendingNotificationChatRoute = false
    @Volatile private var pendingNotificationChatKind = "message"
    @Volatile private var pendingNotificationPeerId = ""
    @Volatile private var pendingNotificationPeerName = ""
    @Volatile private var pendingNotificationRequestId = ""
    @Volatile private var resumeRecoveryToken = 0
    @Volatile private var appInForeground = false
    private val notificationChannelId = "alkamel_events"
    private val notificationPermissionRequest = 7413
    private val wifiScanPermissionRequest = 7414
    private var requestNotificationsOnResume = false
    private val chatRunning = AtomicBoolean(false)
    private val chatRequested = AtomicBoolean(false)
    private val chatSessionGeneration = java.util.concurrent.atomic.AtomicInteger(0)
    @Volatile private var chatSocket: DatagramSocket? = null
    @Volatile private var chatMulticastLock: WifiManager.MulticastLock? = null
    @Volatile private var chatNickname = ""
    private val chatId by lazy { getSharedPreferences("alkamel_mqtt", MODE_PRIVATE).getString("device_id", null) ?: java.util.UUID.randomUUID().toString().also { getSharedPreferences("alkamel_mqtt", MODE_PRIVATE).edit().putString("device_id", it).apply() } }
    private val chatPeerAddresses = ConcurrentHashMap<String, InetAddress>()
    private val chatExecutor = Executors.newSingleThreadExecutor()
    private val chatSendExecutor = Executors.newSingleThreadExecutor()
    private val voiceExecutor = Executors.newSingleThreadExecutor()
    private val voiceReceiveExecutor = Executors.newSingleThreadExecutor()
    private val voiceRunning = AtomicBoolean(false)
    private val voiceSessionGeneration = java.util.concurrent.atomic.AtomicInteger(0)
    private val voiceMuted = AtomicBoolean(false)
    private val voicePlaybackMuted = AtomicBoolean(false)
    @Volatile private var voiceSocket: java.net.MulticastSocket? = null
    @Volatile private var multicastLock: WifiManager.MulticastLock? = null
    private val voiceGroup = InetAddress.getByName("239.10.10.10")
    private val voicePort = 39128
    private val voicePermissionRequest = 7412
    @Volatile private var pendingWebAudioPermissionRequest: android.webkit.PermissionRequest? = null
    private var localFallbackAttempted = false
    private var pendingPageAfterHome: String? = null
    @Volatile private var backgroundedAtMs: Long = 0L
    private val allowedHosts = setOf("k.com", "30.30.30.30", "30.10.10.10", "10.10.10.10")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        restoreFirewallIfNeeded()
        window.statusBarColor = Color.rgb(7, 20, 38)
        window.navigationBarColor = Color.rgb(7, 20, 38)
        CookieManager.getInstance().setAcceptCookie(true)

        root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(7, 20, 38)) }
        web = WebView(this).apply {
            setBackgroundColor(Color.rgb(7, 20, 38))
            // Keep the single WebView warm and hardware accelerated for faster LAN navigation.
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = true
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.loadsImagesAutomatically = true
            settings.blockNetworkImage = false
            settings.cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
            settings.setRenderPriority(android.webkit.WebSettings.RenderPriority.HIGH)
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                settings.offscreenPreRaster = true
            }
            addJavascriptInterface(Bridge(), "AndroidBridge")
            addJavascriptInterface(Bridge(), "Android")
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: android.webkit.PermissionRequest) {
                    runOnUiThread {
                        val trusted = request.origin?.host == "appassets.androidplatform.net"
                        val audioOnly = request.resources.isNotEmpty() && request.resources.all { it == android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE }
                        if (!trusted || !audioOnly) { request.deny(); return@runOnUiThread }
                        val granted = Build.VERSION.SDK_INT < 23 || checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                        if (granted) request.grant(request.resources)
                        else if (pendingWebAudioPermissionRequest == null && Build.VERSION.SDK_INT >= 23) {
                            pendingWebAudioPermissionRequest = request
                            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), voicePermissionRequest)
                        } else request.deny()
                    }
                }
                override fun onConsoleMessage(message: android.webkit.ConsoleMessage): Boolean {
                    Log.d("AlkamelNet-Web", "${message.message()} -- ${message.sourceId()}:${message.lineNumber()}")
                    return true
                }
                override fun onShowCustomView(view: View?, callback: WebChromeClient.CustomViewCallback?) {
                    if (view == null) { callback?.onCustomViewHidden(); return }
                    if (customView != null) { callback?.onCustomViewHidden(); return }
                    customView = view
                    customViewCallback = callback
                    customViewContainer.addView(view, FrameLayout.LayoutParams(-1, -1))
                    customViewContainer.visibility = View.VISIBLE
                    web.visibility = View.GONE
                    requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
                override fun onHideCustomView() { hideCustomView() }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    val uri = request?.url ?: return null
                    val loaded = assetLoader.shouldInterceptRequest(uri)
                    if (loaded != null) return loaded
                    // Compatibility fallback: serve bundled assets directly if the
                    // AndroidX asset loader cannot resolve a local resource.
                    if (uri.host == "appassets.androidplatform.net" && uri.path?.startsWith("/assets/") == true) {
                        val relative = uri.path!!.removePrefix("/assets/")
                        val mime = when (relative.substringAfterLast('.', "").lowercase()) {
                            "html" -> "text/html"
                            "js" -> "application/javascript"
                            "css" -> "text/css"
                            "json" -> "application/json"
                            "png" -> "image/png"
                            "jpg", "jpeg" -> "image/jpeg"
                            "svg" -> "image/svg+xml"
                            "woff", "woff2" -> "font/woff2"
                            "ttf" -> "font/ttf"
                            else -> "application/octet-stream"
                        }
                        val textMime = mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json") || mime.contains("svg")
                        return try {
                            WebResourceResponse(mime, if (textMime) "UTF-8" else null, assets.open(relative))
                        } catch (e: Exception) {
                            Log.e("AlkamelNet", "Missing bundled asset: $relative", e)
                            null
                        }
                    }
                    return null
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    if (uri.host == "appassets.androidplatform.net" && uri.scheme == "https") return false
                    if (uri.scheme == "http" && uri.host in allowedHosts) return false
                    if (uri.scheme == "https" && uri.host == "wa.me" &&
                        uri.path == "/967772072056") {
                        try {
                            startActivity(Intent(Intent.ACTION_VIEW, uri))
                        } catch (e: Exception) {
                            Log.e("AlkamelNet", "Unable to open WhatsApp contact", e)
                            Toast.makeText(this@MainActivity, "تعذر فتح واتساب", Toast.LENGTH_SHORT).show()
                        }
                        return true
                    }
                    Log.w("AlkamelNet", "Blocked navigation: $uri")
                    return true
                }

                override fun onRenderProcessGone(view: WebView?, detail: android.webkit.RenderProcessGoneDetail?): Boolean {
                    Log.e("AlkamelNet", "WebView renderer exited; recovering Activity")
                    runOnUiThread {
                        if (!isFinishing && !isDestroyed) recreate()
                    }
                    return true
                }

                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    // Keep the native JavaScript bridge limited to bundled application pages.
                    // The bundled home is loaded with loadDataWithBaseURL and some
                    // WebView versions report its document URL as data:. Keep the native
                    // bridge attached for that embedded home document; remote service pages
                    // still have the bridge removed.
                    if (urlIsLocal(url) || url?.startsWith("data:") == true) {
                        view?.addJavascriptInterface(Bridge(), "AndroidBridge")
                        view?.addJavascriptInterface(Bridge(), "Android")
                    } else {
                        view?.removeJavascriptInterface("AndroidBridge")
                        view?.removeJavascriptInterface("Android")
                    }
                    // Avoid flashing the full-screen loader for quick local page transitions.
                    if (urlIsLocal(url) || url?.startsWith("http://30.") == true || url?.startsWith("http://10.") == true) {
                        showLoading(false)
                    } else {
                        showLoading(true)
                    }
                    Log.i("AlkamelNet", "Page started: $url")
                }

                override fun onPageCommitVisible(view: WebView?, url: String?) {
                    super.onPageCommitVisible(view, url)
                    showLoading(false)
                    hideError()
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    showLoading(false)
                    Log.i("AlkamelNet", "Page finished: $url")
                    if (url?.startsWith(homeUrl) == true) {
                        view?.evaluateJavascript("""(function(){if(document.getElementById('alkamel-v300-portal-switch'))return;var b=document.createElement('button');b.id='alkamel-v300-portal-switch';b.type='button';b.textContent='بوابة المشترك';b.setAttribute('aria-label','فتح بوابة المشترك الأصلية');b.style.cssText='position:fixed;z-index:2147483647;top:calc(env(safe-area-inset-top,0px) + 8px);left:8px;border:1px solid rgba(125,211,252,.55);border-radius:12px;padding:7px 10px;background:rgba(7,20,38,.92);color:#fff;font:700 12px Cairo,Tahoma,sans-serif;box-shadow:0 4px 18px rgba(0,0,0,.25)';b.onclick=function(){if(window.AndroidBridge&&window.AndroidBridge.openOriginalPortal)window.AndroidBridge.openOriginalPortal();};document.body.appendChild(b);})();""", null)
                    } else if (url?.startsWith(originalPortalUrl) == true) {
                        val returnPage = pendingPageAfterHome
                        pendingPageAfterHome = null
                        if (returnPage == "live" || returnPage == "rest") {
                            view?.evaluateJavascript("if(typeof showPage==='function')showPage('$returnPage');", null)
                        }
                        view?.evaluateJavascript("""(function(){if(document.getElementById('alkamel-v300-ai-switch'))return;var b=document.createElement('button');b.id='alkamel-v300-ai-switch';b.type='button';b.textContent='الرئيسية 3.0.0';b.style.cssText='position:fixed;z-index:2147483647;top:8px;left:8px;border:1px solid #38bdf8;border-radius:10px;padding:7px 10px;background:#071426;color:#fff;font:bold 12px Tahoma,sans-serif';b.onclick=function(){if(window.AndroidBridge&&window.AndroidBridge.openGoogleAiHome)window.AndroidBridge.openGoogleAiHome();};document.body.appendChild(b);})();""", null)
                    }
                    if (url == homeUrl || url?.startsWith(homeUrl) == true) {
                        val returnPage = pendingPageAfterHome
                        pendingPageAfterHome = null
                        if (returnPage == "live" || returnPage == "rest") {
                            view?.evaluateJavascript("if(typeof showPage==='function')showPage('$returnPage');", null)
                        }
                        if (pendingNotificationChatRoute) view?.post { openPendingChatNotificationRoute() }
                        view?.evaluateJavascript("document.documentElement && document.body ? document.body.innerText.length : 0") { value ->
                            val hasContent = value != null && value != "null" && value != "0" && value != "\"\""
                            if (!hasContent) loadHomeFallback("الصفحة الرئيسية فارغة")
                        }
                    }
                }

                @Suppress("DEPRECATION")
                override fun onReceivedError(view: WebView?, errorCode: Int, description: String?, failingUrl: String?) {
                    super.onReceivedError(view, errorCode, description, failingUrl)
                    if (failingUrl == view?.url) {
                        Log.e("AlkamelNet", "Load error $errorCode: $description ($failingUrl)")
                        if (urlIsLocal(failingUrl)) loadHomeFallback(description ?: "خطأ غير معروف")
                        else { showLoading(false); showError("تعذر تحميل الصفحة: ${description ?: "خطأ غير معروف"}") }
                    }
                }

                override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                    super.onReceivedError(view, request, error)
                    if (request?.isForMainFrame == true) {
                        val description = error?.description?.toString() ?: "تعذر تحميل الصفحة"
                        Log.e("AlkamelNet", "Main frame error: $description")
                        if (request?.url?.host == "appassets.androidplatform.net") loadHomeFallback(description)
                        else { showLoading(false); showError("تعذر تحميل الصفحة: $description") }
                    }
                }

                override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?) {
                    super.onReceivedHttpError(view, request, errorResponse)
                    if (request?.isForMainFrame == true) {
                        Log.e("AlkamelNet", "HTTP error ${errorResponse?.statusCode} at ${request.url}")
                        val message = "HTTP ${errorResponse?.statusCode ?: "?"}"
                        if (request.url.host == "appassets.androidplatform.net") loadHomeFallback(message)
                        else { showLoading(false); showError("تعذر فتح الصفحة ($message).") }
                    }
                }
            }
        }

        loading = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(7, 20, 38))
            addView(ProgressBar(this@MainActivity))
            addView(TextView(this@MainActivity).apply {
                text = "جاري تشغيل الكامل-نت…"
                setTextColor(Color.WHITE)
                textSize = 16f
                gravity = Gravity.CENTER
                setPadding(24, 18, 24, 0)
            })
        }
        errorPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 24, 28, 24)
            setBackgroundColor(Color.rgb(7, 20, 38))
            addView(TextView(this@MainActivity).apply {
                text = "تعذر تشغيل التطبيق"
                setTextColor(Color.WHITE)
                textSize = 21f
                gravity = Gravity.CENTER
            })
            addView(TextView(this@MainActivity).apply {
                tag = "error_text"
                setTextColor(Color.LTGRAY)
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(0, 14, 0, 18)
            })
            addView(Button(this@MainActivity).apply {
                text = "إعادة المحاولة"
                setOnClickListener { hideError(); verifyPrivateNetworkAccess { loadHome() } }
            })
        }
        customViewContainer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
        }
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        root.addView(customViewContainer, FrameLayout.LayoutParams(-1, -1))
        root.addView(loading, FrameLayout.LayoutParams(-1, -1))
        root.addView(errorPanel, FrameLayout.LayoutParams(-1, -1))
        errorPanel.visibility = View.GONE
        setContentView(root)
        createEventNotificationChannel()
        showFirstRunSetupIfNeeded()
        // Initialize the hidden portal WebView only when a subscriber changes a setting.
        // Avoid loading a second k.com page during normal app startup.

        // Never restore a WebView history snapshot after Activity/process recreation.
        // Such snapshots can point to expired LAN service sessions and leave the UI
        // visible but unresponsive. Always rebuild the bundled home document instead.
        verifyPrivateNetworkAccess { loadHome() }
    }


    @SuppressLint("SetJavaScriptEnabled")
    private fun initializeCommandWebView() {
        commandWeb = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (url?.startsWith("http://k.com") == true) {
                        view?.evaluateJavascript("if(typeof getRequest==='function')getRequest('/status?var=callBack');", null)
                        view?.evaluateJavascript(
                            "(function(){var n=0;var t=setInterval(function(){n++;if(window.un&&window.un.username){clearInterval(t);window.portalCommandReady=true;}else if(n>=40){clearInterval(t);}},250);})()",
                            null
                        )
                        commandPageReady = true
                        runPendingCommand()
                    }
                }
            }
            alpha = 0f
        }
        commandWeb?.let { hidden ->
            root.addView(hidden, FrameLayout.LayoutParams(1, 1))
            hidden.loadUrl("http://k.com/")
        }
    }

    private fun runPendingCommand() {
        val command = pendingCommand ?: return
        val target = commandWeb ?: return
        if (!commandPageReady || commandAttemptInProgress) return
        commandAttemptInProgress = true
        val speed = JSONObject.quote(command.first)
        val flag = JSONObject.quote(command.second ?: "")
        target.evaluateJavascript(
            "(function(){if(typeof loginst!=='function')return 'missing-loginst';if(!window.un||!window.un.username)return 'subscriber-not-ready';loginst($speed,$flag);return 'submitted';})()"
        ) { result ->
            runOnUiThread {
                commandAttemptInProgress = false
                if (pendingCommand != command) {
                    pendingCommandAttempts = 0
                    runPendingCommand()
                    return@runOnUiThread
                }
                val success = result?.contains("submitted") == true
                val waitingForSubscriber = result?.contains("subscriber-not-ready") == true
                if (waitingForSubscriber && pendingCommandAttempts < 20) {
                    pendingCommandAttempts++
                    target.postDelayed({ runPendingCommand() }, 500)
                    return@runOnUiThread
                }
                pendingCommand = null
                pendingCommandAttempts = 0
                val message = when {
                    success -> "تم تمرير الطلب إلى كود الموقع الأصلي."
                    waitingForSubscriber -> "لم تكتمل قراءة بيانات المشترك من بوابة الشبكة؛ لم يتم إرسال الطلب."
                    else -> "تعذر العثور على دالة الموقع الأصلية؛ لم يتم إرسال الطلب."
                }
                web.evaluateJavascript(
                    "if(document.getElementById('speedNotice')){document.getElementById('speedNotice').textContent=${JSONObject.quote(message)};if(${success})setTimeout(function(){if(window.AndroidBridge)AndroidBridge.refresh();},1200);}if(document.getElementById('googleNotice'))document.getElementById('googleNotice').textContent=${JSONObject.quote(message)};",
                    null
                )
                if (!success) Log.e("AlkamelNet", "Original portal command was not submitted: $result")
            }
        }
    }


    private fun ensureBackgroundService() {
        val intent = Intent(this, ChatKeepAliveService::class.java).apply { action = ChatKeepAliveService.ACTION_START }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        } catch (e: Exception) {
            Log.e("AlkamelNet", "Unable to keep app alive in background", e)
            Toast.makeText(this, "تعذر تفعيل العمل في الخلفية. تحقق من إعدادات البطارية.", Toast.LENGTH_LONG).show()
        }
    }

    private fun showFirstRunSetupIfNeeded() {
        val prefs = getSharedPreferences("alkamel_app_setup", MODE_PRIVATE)
        if (prefs.getBoolean("first_run_setup_asked", false)) {
            if (prefs.getBoolean("background_enabled", false)) ensureBackgroundService()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("تفعيل عمل شبكة الكامل في الخلفية")
            .setMessage("فعّل خدمة العمل في الخلفية لتستمر خدمات الشبكة والدردشة عند تصغير التطبيق. سنطلب إذن الإشعارات لتنبيهك بالرسائل والإعلانات المهمة.")
            .setCancelable(false)
            .setNegativeButton("لاحقاً") { _, _ ->
                prefs.edit().putBoolean("first_run_setup_asked", true).apply()
            }
            .setPositiveButton("تفعيل الآن") { _, _ ->
                prefs.edit().putBoolean("first_run_setup_asked", true).putBoolean("background_enabled", true).apply()
                ensureBackgroundService()
                requestNotificationsOnResume = false
                requestNotificationPermission()
                Toast.makeText(this, "تم تفعيل خدمة العمل في الخلفية.", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun createEventNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(notificationChannelId, "تنبيهات شبكة الكامل", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "إشعارات الدردشة والإعلانات والعروض والتنبيهات المهمة"
                enableVibration(true)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), notificationPermissionRequest)
        }
    }

    private fun postEventNotification(title: String, message: String, notificationId: Int) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val openApp = PendingIntent.getActivity(
            this, notificationId,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, notificationChannelId) else {
            @Suppress("DEPRECATION") Notification.Builder(this)
        }
        val notification = builder.setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(title).setContentText(message.take(180))
            .setStyle(Notification.BigTextStyle().bigText(message.take(500)))
            .setAutoCancel(true).setContentIntent(openApp).build()
        getSystemService(NotificationManager::class.java).notify(notificationId, notification)
    }

    private fun notifyIncomingChat(obj: JSONObject) {
        if (appInForeground) return
        val type = obj.optString("type")
        val sender = obj.optString("name", "عضو")
        val message = obj.optString("text").trim()
        val privateMessage = type == "private_message" && obj.optString("to") == chatId
        val privateRequest = type == "private_request" && obj.optString("to") == chatId
        val nickname = chatNickname.trim()
        val mentioned = nickname.isNotEmpty() && message.contains(nickname, ignoreCase = true)
        if (!privateMessage && !privateRequest && !(type == "message" && mentioned)) return
        val title = when {
            privateRequest -> "طلب محادثة خاصة جديد"
            privateMessage -> "رسالة خاصة جديدة من $sender"
            else -> "تم ذكرك في دردشة شبكة الكامل"
        }
        val body = when {
            privateRequest -> "يريد $sender بدء محادثة خاصة معك."
            else -> "$sender: $message"
        }
        postEventNotification(title, body, (System.currentTimeMillis() % 2000000000L).toInt())
    }

    private fun startLanChat(name: String, ensureService: Boolean = true) {
        val clean = name.trim().take(24)
        if (clean.isEmpty()) return
        chatNickname = clean
        chatRequested.set(true)
        if (ensureService && getSharedPreferences("alkamel_app_setup", MODE_PRIVATE).getBoolean("background_enabled", false)) {
        val keepAlive = Intent(this, ChatKeepAliveService::class.java).apply { action = ChatKeepAliveService.ACTION_START }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(keepAlive) else startService(keepAlive)
        } catch (e: Exception) {
            Log.e("AlkamelNet", "Unable to start background chat service", e)
            runOnUiThread { if (::web.isInitialized && !isDestroyed) web.evaluateJavascript("window.onChatServiceError&&window.onChatServiceError();", null) }
        }
        }
        if (!chatRunning.compareAndSet(false, true)) {
            sendLanPacket("presence", "")
            return
        }
        val sessionId = chatSessionGeneration.incrementAndGet()
        chatExecutor.execute {
            var sessionSocket: DatagramSocket? = null
            var sessionMulticastLock: WifiManager.MulticastLock? = null
            try {
                if (chatSessionGeneration.get() != sessionId || !chatRunning.get()) return@execute
                // Bind the receiver to Wi-Fi explicitly; wildcard UDP sockets can
                // otherwise follow Android's cellular/default route and miss LAN packets.
                val wifiNetwork = chatWifiNetwork()
                val wifi = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
                runCatching {
                    sessionMulticastLock = wifi.createMulticastLock("AlkamelNetChat").apply {
                        setReferenceCounted(false)
                        acquire()
                    }
                    chatMulticastLock = sessionMulticastLock
                }.onFailure { Log.w("AlkamelNet", "Unable to acquire chat Wi-Fi receive lock", it) }
                val socket = DatagramSocket(null).apply {
                    reuseAddress = true
                    soTimeout = 1000
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP && wifiNetwork != null) {
                        runCatching { wifiNetwork.bindSocket(this) }
                            .onFailure { Log.w("AlkamelNet", "Unable to bind chat receiver to Wi-Fi network", it) }
                    }
                    bind(java.net.InetSocketAddress(39127))
                }
                sessionSocket = socket
                if (chatSessionGeneration.get() != sessionId || !chatRunning.get()) {
                    socket.close()
                    return@execute
                }
                chatSocket = socket
                notifyChatState("joined", "")
                var lastPresence = 0L
                while (chatRunning.get() && chatSessionGeneration.get() == sessionId) {
                    val now = System.currentTimeMillis()
                    if (now - lastPresence >= 5000) { sendLanPacket("presence", ""); lastPresence = now }
                    try {
                        val buffer = ByteArray(4096); val packet = DatagramPacket(buffer, buffer.size); socket.receive(packet)
                        val raw = String(packet.data, packet.offset, packet.length, Charsets.UTF_8)
                        val obj = JSONObject(raw)
                        val packetType = obj.optString("type")
                        val senderId = obj.optString("id")
                        if (senderId != chatId) {
                            // Learn the sender's current LAN address from both presence and
                            // private handshake packets. The receiver may not have seen the
                            // sender's latest broadcast yet when it needs to accept/reject.
                            if (packetType in setOf("presence", "profile_photo", "private_request", "private_response", "private_message")) {
                                chatPeerAddresses[senderId] = packet.address
                            }
                            val isPublicPacket = packetType in setOf("presence", "message", "profile_photo", "gift", "voice_seat")
                            val isPrivatePacket = packetType in setOf("private_request", "private_response", "private_message") && obj.optString("to") == chatId
                            if (isPublicPacket || isPrivatePacket) {
                                if (packetType == "message" || packetType == "private_message" || packetType == "private_request") {
                                    try { notifyIncomingChat(obj) } catch (notificationError: Exception) { Log.w("AlkamelNet", "Unable to show chat notification", notificationError) }
                                }
                                runOnUiThread { if (::web.isInitialized && !isFinishing && !isDestroyed) web.evaluateJavascript("if(window.onLanChatPacket)window.onLanChatPacket(${JSONObject.quote(raw)});", null) }
                            }
                        }
                    } catch (_: SocketTimeoutException) { }
                }
            } catch (e: SocketException) {
                // Closing a DatagramSocket while receive() is blocked raises EBADF.
                // Treat intentional shutdown as normal; retry unexpected socket loss.
                if (chatRunning.get() && chatRequested.get() && chatSessionGeneration.get() == sessionId) {
                    Log.w("AlkamelNet", "LAN chat socket interrupted; preparing reconnect", e)
                    chatRunning.set(false)
                    notifyChatState("reconnecting", "انقطع اتصال الدردشة مؤقتاً، جارٍ إعادة الاتصال…")
                    try { Thread.sleep(1200) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
                    if (chatRequested.get() && chatSessionGeneration.get() == sessionId) startLanChat(chatNickname, ensureService = false)
                }
            } catch (e: Exception) {
                if (chatRunning.get() && chatRequested.get() && chatSessionGeneration.get() == sessionId) {
                    Log.e("AlkamelNet", "LAN chat socket failed", e)
                    chatRunning.set(false)
                    notifyChatState("reconnecting", "حدث انقطاع في اتصال الدردشة، جارٍ إعادة المحاولة…")
                    try { Thread.sleep(1500) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
                    if (chatRequested.get()) startLanChat(chatNickname, ensureService = false)
                } else {
                    Log.d("AlkamelNet", "LAN chat receiver stopped during socket cleanup")
                }
            } finally {
                try { sessionSocket?.close() } catch (_: Exception) { }
                if (chatSocket === sessionSocket) chatSocket = null
                runCatching { sessionMulticastLock?.let { if (it.isHeld) it.release() } }
                    .onFailure { Log.w("AlkamelNet", "Unable to release chat Wi-Fi lock", it) }
                if (chatMulticastLock === sessionMulticastLock) chatMulticastLock = null
            }
        }
    }
    private fun notifyChatState(state: String, detail: String) {
        val stateJson = JSONObject.quote(state)
        val detailJson = JSONObject.quote(detail)
        runOnUiThread {
            if (::web.isInitialized && !isFinishing && !isDestroyed) {
                web.evaluateJavascript("window.onChatState&&window.onChatState($stateJson,$detailJson);", null)
            }
        }
    }

    /** Select the connected Wi-Fi network rather than Android's default route. */
    private fun chatWifiNetwork(): Network? {
        return try {
            val connectivity = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val candidates = buildList {
                connectivity.activeNetwork?.let { add(it) }
                addAll(connectivity.allNetworks)
            }.distinct()
            candidates.firstOrNull { network ->
                connectivity.getNetworkCapabilities(network)
                    ?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
            }
        } catch (e: Exception) {
            Log.w("AlkamelNet", "Unable to identify active Wi-Fi network for chat", e)
            null
        }
    }

    /**
     * Resolve broadcast routes from the actual local interfaces instead of relying
     * only on ConnectivityManager.activeNetwork. Android may report cellular as the
     * active default network while Wi-Fi is still the LAN used by the chat room.
     */
    private fun chatBroadcastRoutes(): List<Pair<InetAddress, InetAddress>> {
        val routes = linkedMapOf<String, Pair<InetAddress, InetAddress>>()
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()?.asSequence()?.toList().orEmpty()
            interfaces.forEach { network ->
                val name = network.name.lowercase()
                val isLanInterface = name.startsWith("wlan") || name.startsWith("wifi") ||
                    name.startsWith("ap") || name.startsWith("eth")
                if (!isLanInterface || !runCatching { network.isUp && !network.isLoopback && !network.isVirtual }.getOrDefault(false)) {
                    return@forEach
                }
                network.interfaceAddresses.forEach { address ->
                    val local = address.address
                    val broadcast = address.broadcast
                    if (local is java.net.Inet4Address && broadcast is java.net.Inet4Address &&
                        !local.isLoopbackAddress && !local.isLinkLocalAddress && !broadcast.isAnyLocalAddress) {
                        val key = "${local.hostAddress}->${broadcast.hostAddress}"
                        routes[key] = local to broadcast
                    }
                }
            }
        } catch (e: Exception) {
            Log.w("AlkamelNet", "Unable to enumerate LAN broadcast interfaces", e)
        }
        return routes.values.toList()
    }

    private fun sendLanPacket(type: String, message: String) {
        if (!chatRunning.get()) return
        val sessionId = chatSessionGeneration.get()
        val messageId = if (type == "message") java.util.UUID.randomUUID().toString() else ""
        val payload = JSONObject().put("type", type).put("id", chatId).put("name", chatNickname)
            .put("text", message).apply { if (messageId.isNotEmpty()) put("messageId", messageId) }
            .toString().toByteArray(Charsets.UTF_8)
        if (payload.size > 3900) {
            Log.w("AlkamelNet", "LAN packet too large and was not sent: $type")
            return
        }
        chatSendExecutor.execute {
            if (!chatRunning.get() || chatSessionGeneration.get() != sessionId) return@execute
            try {
                val routes = chatBroadcastRoutes()
                val limitedBroadcast = InetAddress.getByName("255.255.255.255")
                val copies = if (type == "message") 3 else 1
                if (routes.isEmpty()) {
                    DatagramSocket(null).use { sender ->
                        sender.broadcast = true
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            chatWifiNetwork()?.let { network ->
                                runCatching { network.bindSocket(sender) }
                                    .onFailure { Log.w("AlkamelNet", "Unable to bind fallback chat sender to Wi-Fi", it) }
                            }
                        }
                        sender.bind(java.net.InetSocketAddress(0))
                        repeat(copies) { index ->
                            if (chatRunning.get() && chatSessionGeneration.get() == sessionId) sender.send(DatagramPacket(payload, payload.size, limitedBroadcast, 39127))
                            if (index < copies - 1) Thread.sleep(90)
                        }
                    }
                } else {
                    routes.forEach { (localAddress, subnetBroadcast) ->
                        if (!chatRunning.get() || chatSessionGeneration.get() != sessionId) return@forEach
                        DatagramSocket(null).use { sender ->
                            sender.reuseAddress = true
                            sender.broadcast = true
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                                chatWifiNetwork()?.let { network ->
                                    runCatching { network.bindSocket(sender) }
                                        .onFailure { Log.w("AlkamelNet", "Unable to bind chat sender to Wi-Fi", it) }
                                }
                            }
                            sender.bind(java.net.InetSocketAddress(localAddress, 0))
                            repeat(copies) { index ->
                                if (chatRunning.get() && chatSessionGeneration.get() == sessionId) {
                                    sender.send(DatagramPacket(payload, payload.size, subnetBroadcast, 39127))
                                    // Limited broadcast is retained as a fallback for APs
                                    // that do not forward the calculated subnet broadcast.
                                    if (subnetBroadcast != limitedBroadcast) {
                                        sender.send(DatagramPacket(payload, payload.size, limitedBroadcast, 39127))
                                    }
                                }
                                if (index < copies - 1) Thread.sleep(90)
                            }
                        }
                    }
                }
                Log.d("AlkamelNet", "LAN chat packet sent through ${routes.size} LAN interfaces")
            } catch (e: Exception) {
                Log.w("AlkamelNet", "LAN chat send failed", e)
            }
        }
    }
    private fun sendPrivateLanPacket(type: String, targetId: String, requestId: String, message: String) {
        if (!chatRunning.get() || targetId.isBlank() || requestId.isBlank()) return
        val sessionId = chatSessionGeneration.get()
        val address = chatPeerAddresses[targetId] ?: run {
            Log.w("AlkamelNet", "Private chat target is not present in the LAN peer table")
            return
        }
        val payload = JSONObject()
            .put("type", type)
            .put("id", chatId)
            .put("name", chatNickname)
            .put("to", targetId)
            .put("requestId", requestId)
            .put("text", message.take(1000))
            .toString().toByteArray(Charsets.UTF_8)
        chatSendExecutor.execute {
            if (!chatRunning.get() || chatSessionGeneration.get() != sessionId) return@execute
            try {
                DatagramSocket(null).use { sender ->
                    // Private unicast packets must follow the same Wi-Fi route as
                    // group chat; otherwise Android may send them over cellular.
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        chatWifiNetwork()?.let { network ->
                            runCatching { network.bindSocket(sender) }
                                .onFailure { Log.w("AlkamelNet", "Unable to bind private chat sender to Wi-Fi", it) }
                        }
                    }
                    sender.bind(java.net.InetSocketAddress(0))
                    sender.send(DatagramPacket(payload, payload.size, address, 39127))
                }
            } catch (e: Exception) {
                Log.w("AlkamelNet", "Private LAN packet send failed", e)
            }
        }
    }

    private fun stopLanChat() {
        chatSessionGeneration.incrementAndGet()
        chatRequested.set(false)
        chatRunning.set(false)
        chatPeerAddresses.clear()
        chatSocket?.close()
        chatSocket = null
        runCatching { chatMulticastLock?.let { if (it.isHeld) it.release() } }
            .onFailure { Log.w("AlkamelNet", "Unable to release chat Wi-Fi lock", it) }
        chatMulticastLock = null
        notifyChatState("stopped", "")
    }


    private fun requestVoiceRoom() {
        runOnUiThread {
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), voicePermissionRequest)
            } else startVoiceRoom()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == wifiScanPermissionRequest) {
            if (grantResults.size > 1 && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                performNearbyWifiScan()
            } else {
                runOnUiThread { if (::web.isInitialized) web.evaluateJavascript("window.onNearbyWifiResult&&window.onNearbyWifiResult({error:'يلزم السماح بإذن الموقع لعرض الشبكات القريبة'});", null) }
            }
            return
        }
        if (requestCode == voicePermissionRequest) {
            val permissionGranted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            val webRequest = pendingWebAudioPermissionRequest
            pendingWebAudioPermissionRequest = null
            if (webRequest != null) {
                runOnUiThread {
                    if (permissionGranted) webRequest.grant(webRequest.resources) else webRequest.deny()
                    if (!permissionGranted && ::web.isInitialized) {
                        web.evaluateJavascript("if(window.onVoiceNotePermissionError)window.onVoiceNotePermissionError();", null)
                    }
                }
            } else if (permissionGranted) {
                startVoiceRoom()
            } else {
                runOnUiThread { web.evaluateJavascript("window.onVoiceState&&window.onVoiceState('error','لم تسمح باستخدام الميكروفون');", null) }
            }
        }
    }

    private fun startVoiceRoom() {
        if (!chatRunning.get()) {
            web.evaluateJavascript("window.onVoiceState&&window.onVoiceState('error','ادخل الدردشة النصية أولاً');", null)
            return
        }
        if (!voiceRunning.compareAndSet(false, true)) return
        val sessionId = voiceSessionGeneration.incrementAndGet()
        voiceMuted.set(false)
        voicePlaybackMuted.set(false)
        voiceExecutor.execute {
            var recorder: AudioRecord? = null
            var player: AudioTrack? = null
            var echoCanceler: AcousticEchoCanceler? = null
            var noiseSuppressor: NoiseSuppressor? = null
            var automaticGain: AutomaticGainControl? = null
            var sessionSocket: java.net.MulticastSocket? = null
            var sessionMulticastLock: WifiManager.MulticastLock? = null
            try {
                if (voiceSessionGeneration.get() != sessionId || !voiceRunning.get()) return@execute
                val wifi = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
                sessionMulticastLock = wifi.createMulticastLock("AlkamelNetVoice").apply { setReferenceCounted(false); acquire() }
                multicastLock = sessionMulticastLock
                // Select the active Wi-Fi interface explicitly; Android may otherwise
                // attach multicast traffic to a mobile/virtual interface.
                val connectivity = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
                val activeNetwork = connectivity.activeNetwork
                val activeCapabilities = activeNetwork?.let { connectivity.getNetworkCapabilities(it) }
                val activeInterfaceName = if (activeCapabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) {
                    activeNetwork?.let { connectivity.getLinkProperties(it)?.interfaceName }
                } else null
                val wifiInterface = activeInterfaceName?.let { runCatching { NetworkInterface.getByName(it) }.getOrNull() }
                    ?.takeIf { it.isUp && !it.isLoopback }
                    ?: NetworkInterface.getNetworkInterfaces().toList()
                        .firstOrNull { it.isUp && !it.isLoopback && (it.name.startsWith("wlan") || it.name.startsWith("wifi")) }
                    ?: throw IllegalStateException("لم يتم العثور على واجهة Wi-Fi نشطة")
                val socket = java.net.MulticastSocket(null).apply {
                    reuseAddress = true
                    timeToLive = 1
                    soTimeout = 200
                    bind(java.net.InetSocketAddress(voicePort))
                    networkInterface = wifiInterface
                    joinGroup(java.net.InetSocketAddress(voiceGroup, voicePort), wifiInterface)
                }
                sessionSocket = socket
                voiceSocket = socket
                val rate = 16000
                val inputMask = AudioFormat.CHANNEL_IN_MONO
                val outputMask = AudioFormat.CHANNEL_OUT_MONO
                val encoding = AudioFormat.ENCODING_PCM_16BIT
                val minIn = AudioRecord.getMinBufferSize(rate, inputMask, encoding)
                val minOut = AudioTrack.getMinBufferSize(rate, outputMask, encoding)
                if (minIn <= 0 || minOut <= 0) throw IllegalStateException("Audio device unavailable")
                val frame = 640
                recorder = AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(encoding).setChannelMask(inputMask).build())
                    .setBufferSizeInBytes(maxOf(minIn, frame * 8)).build()
                if (recorder?.state != AudioRecord.STATE_INITIALIZED) {
                    throw IllegalStateException("تعذر تهيئة الميكروفون. أغلق التطبيقات التي تستخدمه ثم حاول مجدداً")
                }
                player = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(encoding).setChannelMask(outputMask).build())
                    .setBufferSizeInBytes(maxOf(minOut, frame * 8)).setTransferMode(AudioTrack.MODE_STREAM).build()
                if (player?.state != AudioTrack.STATE_INITIALIZED) {
                    throw IllegalStateException("تعذر تهيئة مخرج الصوت في الهاتف")
                }
                val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
                audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val speaker = audioManager.availableCommunicationDevices.firstOrNull {
                        it.type == android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
                    }
                    if (speaker != null) audioManager.setCommunicationDevice(speaker)
                } else {
                    @Suppress("DEPRECATION")
                    run { audioManager.isSpeakerphoneOn = true }
                }
                val activeRecorder = recorder
                val activePlayer = player
                // Audio effects are optional and vary by device/vendor. A failure
                // to create one must never prevent the voice room from starting.
                if (AcousticEchoCanceler.isAvailable()) {
                    echoCanceler = runCatching { AcousticEchoCanceler.create(activeRecorder.audioSessionId)?.apply { enabled = true } }
                        .onFailure { Log.w("AlkamelNet", "Echo cancellation unavailable", it) }.getOrNull()
                }
                if (NoiseSuppressor.isAvailable()) {
                    noiseSuppressor = runCatching { NoiseSuppressor.create(activeRecorder.audioSessionId)?.apply { enabled = true } }
                        .onFailure { Log.w("AlkamelNet", "Noise suppression unavailable", it) }.getOrNull()
                }
                activeRecorder.startRecording()
                if (activeRecorder.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                    throw IllegalStateException("الميكروفون لم يبدأ التسجيل. تحقق من إذن الميكروفون")
                }
                activePlayer.setVolume(1.0f)
                activePlayer.play()
                runOnUiThread { if (::web.isInitialized && !isDestroyed) web.evaluateJavascript("window.onVoiceState&&window.onVoiceState('joined','');", null) }

                voiceReceiveExecutor.execute {
                    val incoming = ByteArray(1200)
                    while (voiceRunning.get() && voiceSessionGeneration.get() == sessionId) {
                        try {
                            val packet = DatagramPacket(incoming, incoming.size)
                            socket.receive(packet)
                            val end = (packet.offset until packet.offset + packet.length).firstOrNull { incoming[it] == 10.toByte() } ?: continue
                            val sender = String(incoming, packet.offset, end - packet.offset, Charsets.UTF_8)
                            if (sender == chatId) continue
                            val start = end + 1
                            val count = packet.offset + packet.length - start
                            if (count > 0) {
                                activePlayer.setVolume(if (voicePlaybackMuted.get()) 0.0f else 1.0f)
                                activePlayer.write(incoming, start, count)
                                runOnUiThread { if (!isFinishing) web.evaluateJavascript("window.onVoiceActivity&&window.onVoiceActivity(${JSONObject.quote(sender)});", null) }
                            }
                        } catch (_: SocketTimeoutException) { }
                        catch (e: Exception) { if (voiceRunning.get()) Log.w("AlkamelNet", "Voice receive failed", e) }
                    }
                }

                val pcm = ByteArray(frame)
                var softwareGain = 1.0
                val prefix = (chatId + "\n").toByteArray(Charsets.UTF_8)
                val outgoing = ByteArray(prefix.size + frame)
                System.arraycopy(prefix, 0, outgoing, 0, prefix.size)
                var lastUi = 0L
                while (voiceRunning.get() && voiceSessionGeneration.get() == sessionId) {
                    // Non-blocking reads let the stop flag end the audio loop
                    // immediately; READ_BLOCKING can strand the single voice worker
                    // after leaving a room and prevent joining again.
                    val count = activeRecorder.read(pcm, 0, pcm.size, AudioRecord.READ_NON_BLOCKING)
                    if (!voiceRunning.get() || voiceSessionGeneration.get() != sessionId) break
                    if (count == AudioRecord.ERROR_INVALID_OPERATION || count == AudioRecord.ERROR_BAD_VALUE || count == AudioRecord.ERROR_DEAD_OBJECT) {
                        throw IllegalStateException("توقف تسجيل الميكروفون (رمز " + count + ")")
                    }
                    if (count <= 0) {
                        try { Thread.sleep(5) } catch (_: InterruptedException) {
                            Thread.currentThread().interrupt()
                            break
                        }
                        continue
                    }
                    var energy = 0.0
                    var i = 0
                    while (i + 1 < count) {
                        val sample = ((pcm[i + 1].toInt() shl 8) or (pcm[i].toInt() and 255)).toShort().toInt()
                        energy += sample.toDouble() * sample.toDouble()
                        i += 2
                    }
                    val rms = kotlin.math.sqrt(energy / (count / 2).coerceAtLeast(1))
                    // Far-field voice pickup: adaptive level target, fast gain attack, slow release.
                    val speaking = !voiceMuted.get() && rms > 180.0
                    if (!voiceMuted.get()) {
                        val targetGain = if (rms < 55.0) {
                            1.0
                        } else {
                            (2600.0 / rms).coerceIn(1.0, 8.0)
                        }
                        val smoothing = if (targetGain > softwareGain) 0.32 else 0.10
                        softwareGain += (targetGain - softwareGain) * smoothing
                        var sampleIndex = 0
                        while (sampleIndex + 1 < count) {
                            val rawSample = ((pcm[sampleIndex + 1].toInt() shl 8) or (pcm[sampleIndex].toInt() and 255)).toShort().toInt()
                            val amplified = (rawSample * softwareGain).toInt().coerceIn(-32768, 32767)
                            pcm[sampleIndex] = amplified.toByte()
                            pcm[sampleIndex + 1] = (amplified shr 8).toByte()
                            sampleIndex += 2
                        }
                        System.arraycopy(pcm, 0, outgoing, prefix.size, count)
                        socket.send(DatagramPacket(outgoing, prefix.size + count, voiceGroup, voicePort))
                    }
                    val now = System.currentTimeMillis()
                    if (now - lastUi > 300) {
                        val state = if (voiceMuted.get()) "muted" else if (speaking) "speaking" else "joined"
                        runOnUiThread { if (!isFinishing) web.evaluateJavascript("window.onVoiceState&&window.onVoiceState(${JSONObject.quote(state)},'');", null) }
                        lastUi = now
                    }
                }
            } catch (e: Exception) {
                Log.e("AlkamelNet", "Voice room failed", e)
                if (voiceSessionGeneration.get() == sessionId) {
                    runOnUiThread { if (!isFinishing) web.evaluateJavascript("window.onVoiceState&&window.onVoiceState('error'," + JSONObject.quote(e.localizedMessage ?: "Voice room error") + ");", null) }
                }
            } finally {
                if (voiceSessionGeneration.get() == sessionId) voiceRunning.set(false)
                try { recorder?.stop() } catch (_: Exception) { }
                try { echoCanceler?.release() } catch (_: Exception) { }
                try { noiseSuppressor?.release() } catch (_: Exception) { }
                try { automaticGain?.release() } catch (_: Exception) { }
                try { recorder?.release() } catch (_: Exception) { }
                try { player?.stop() } catch (_: Exception) { }
                try { player?.release() } catch (_: Exception) { }
                sessionSocket?.let { try { it.leaveGroup(voiceGroup); it.close() } catch (_: Exception) { } }
                if (voiceSocket === sessionSocket) voiceSocket = null
                sessionMulticastLock?.let { try { if (it.isHeld) it.release() } catch (_: Exception) { } }
                if (multicastLock === sessionMulticastLock) multicastLock = null
                val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    try { audioManager.clearCommunicationDevice() } catch (_: Exception) { }
                }
                audioManager.mode = AudioManager.MODE_NORMAL
                @Suppress("DEPRECATION")
                run { audioManager.isSpeakerphoneOn = false }
            }
        }
    }

    private fun setVoicePlaybackMute(muted: Boolean) {
        voicePlaybackMuted.set(muted)
        runOnUiThread {
            if (::web.isInitialized && !isFinishing) web.evaluateJavascript("window.onVoicePlaybackState&&window.onVoicePlaybackState(" + muted + ");", null)
        }
    }

    private fun setVoiceMute(muted: Boolean) {
        voiceMuted.set(muted)
        if (voiceRunning.get()) {
            val state = if (muted) "muted" else "joined"
            runOnUiThread { web.evaluateJavascript("window.onVoiceState&&window.onVoiceState(${JSONObject.quote(state)},'');", null) }
        }
    }

    private fun stopVoiceRoom() {
        // Invalidate the current worker before closing its socket. A rapid leave/join
        // must never let an older worker keep running or clear the newer session.
        voiceSessionGeneration.incrementAndGet()
        voiceRunning.set(false)
        voiceSocket?.close()
        voiceSocket = null
    }

    private fun urlIsLocal(url: String?): Boolean = url?.startsWith("https://appassets.androidplatform.net/assets/") == true

    private fun loadHomeFallback(reason: String) {
        if (localFallbackAttempted || isFinishing) {
            showLoading(false)
            showError("تعذر تشغيل واجهة التطبيق. $reason")
            return
        }
        localFallbackAttempted = true
        io.execute {
            try {
                val html = assets.open("googleai/index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
                runOnUiThread {
                    if (!isFinishing && ::web.isInitialized) {
                        Log.w("AlkamelNet", "Loading home through embedded HTML fallback: $reason")
                        web.loadDataWithBaseURL(homeUrl, html, "text/html", "UTF-8", null)
                    }
                }
            } catch (e: Exception) {
                Log.e("AlkamelNet", "Embedded home fallback failed", e)
                showLoading(false)
                showError("تعذر قراءة ملفات واجهة التطبيق: ${e.localizedMessage ?: reason}")
            }
        }
    }

    /**
     * Access is granted only while the private portal is reachable. This check
     * deliberately uses the portal itself rather than the Wi-Fi name, because
     * SSIDs can be copied by unrelated networks.
     */
    private fun isPrivateNetworkReachable(): Boolean =
        listOf("k.com", "k.net").any { host ->
            try {
                val connection = (URL("http://$host/").openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 2200
                    readTimeout = 2200
                    instanceFollowRedirects = false
                    useCaches = false
                    setRequestProperty("Cache-Control", "no-cache, no-store")
                    setRequestProperty("Connection", "close")
                }
                try {
                    val status = connection.responseCode
                    status in 200..399 && connection.url.host.equals(host, ignoreCase = true)
                } finally {
                    connection.disconnect()
                }
            } catch (e: Exception) {
                Log.d("AlkamelNet", "Private network check failed for $host: ${e.message}")
                false
            }
        }

    private fun startNetworkAccessGuard() {
        if (networkGuardStarted) return
        networkGuardStarted = true
        networkGuard.scheduleWithFixedDelay({
            val reachable = isPrivateNetworkReachable()
            if (reachable) {
                networkFailureCount = 0
                if (networkAccessBlocked) {
                    networkSuccessCount++
                    if (networkSuccessCount >= 1) {
                        networkAccessBlocked = false
                        mainHandler.post {
                            if (!isFinishing && !isDestroyed) {
                                hideError()
                                loadHome()
                                val prefs = getSharedPreferences("alkamel_app_setup", MODE_PRIVATE)
                                if (prefs.getBoolean("background_enabled", false)) ensureBackgroundService()
                                Toast.makeText(this, "تم استعادة الاتصال بشبكة الكامل.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                } else networkSuccessCount = 0
            } else {
                networkSuccessCount = 0
                networkFailureCount++
                if (networkFailureCount >= 2 && !networkAccessBlocked) {
                    networkAccessBlocked = true
                    mainHandler.post {
                        if (!isFinishing && !isDestroyed) {
                            Log.w("AlkamelNet", "Private network lost; locking app and stopping LAN services")
                            stopVoiceRoom()
                            stopLanChat()
                            commandWeb?.stopLoading()
                            web.stopLoading()
                            web.evaluateJavascript("(function(){document.querySelectorAll('video,audio').forEach(function(m){try{m.pause();m.currentTime=0;}catch(e){}});})()", null)
                            stopService(Intent(this, ChatKeepAliveService::class.java).setAction(ChatKeepAliveService.ACTION_STOP))
                            showError("انقطع اتصالك بشبكة الكامل. تم إيقاف خدمات التطبيق؛ اتصل بشبكة الكامل للمتابعة.")
                        }
                    }
                }
            }
        }, 5, 5, java.util.concurrent.TimeUnit.SECONDS)
    }

    private fun verifyPrivateNetworkAccess(onAllowed: (() -> Unit)? = null) {
        if (isFinishing || isDestroyed) return
        showLoading(true)
        errorPanel.visibility = View.GONE
        startNetworkAccessGuard()
        io.execute {
            val reachable = isPrivateNetworkReachable()
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                showLoading(false)
                if (reachable) {
                    networkAccessBlocked = false
                    networkFailureCount = 0
                    networkSuccessCount = 0
                    hideError()
                    onAllowed?.invoke()
                } else {
                    networkAccessBlocked = true
                    stopService(Intent(this, ChatKeepAliveService::class.java).setAction(ChatKeepAliveService.ACTION_STOP))
                    showError("هذا التطبيق مخصص لمشتركي شبكة الكامل. اتصل بشبكة الكامل ثم أعد المحاولة.")
                }
            }
        }
    }

    private fun loadHome() {
        try {
            lastHomeUrl = homeUrl
            showErrorHidden()
            showLoading(true)
            // Load the bundled HTML directly as the primary route. This avoids
            // depending on WebViewAssetLoader for the first document, which can
            // otherwise leave older WebView implementations on a blank screen.
            localFallbackAttempted = true
            // Reattach before every local home load so returning from external
            // lounge/live pages never leaves the JavaScript bridge unavailable.
            web.addJavascriptInterface(Bridge(), "AndroidBridge")
            web.addJavascriptInterface(Bridge(), "Android")
            val html = assets.open("googleai/index.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
            web.loadDataWithBaseURL(homeUrl, html, "text/html", "UTF-8", null)
        } catch (e: Exception) {
            Log.e("AlkamelNet", "Embedded home load failed; trying asset URL", e)
            try {
                localFallbackAttempted = false
                web.loadUrl(homeUrl)
            } catch (second: Exception) {
                Log.e("AlkamelNet", "Unable to load home", second)
                showLoading(false)
                showError("تعذر بدء واجهة التطبيق: ${second.localizedMessage ?: e.localizedMessage ?: "خطأ غير معروف"}")
            }
        }
    }

    private fun showLoading(show: Boolean) {
        if (!::loading.isInitialized) return
        runOnUiThread { loading.visibility = if (show) View.VISIBLE else View.GONE }
    }

    private fun hideError() {
        if (!::errorPanel.isInitialized) return
        runOnUiThread { errorPanel.visibility = View.GONE }
    }

    private fun showErrorHidden() {
        if (::errorPanel.isInitialized) errorPanel.visibility = View.GONE
    }

    private fun showError(message: String) {
        if (!::errorPanel.isInitialized || isFinishing) return
        runOnUiThread {
            errorPanel.findViewWithTag<TextView>("error_text")?.text = message
            errorPanel.visibility = View.VISIBLE
        }
    }

    private fun requestNearbyWifiScan() {
        if (checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.ACCESS_COARSE_LOCATION, android.Manifest.permission.ACCESS_FINE_LOCATION), wifiScanPermissionRequest)
            return
        }
        performNearbyWifiScan()
    }

    private fun performNearbyWifiScan() {
        if (!::web.isInitialized || isFinishing || isDestroyed) return
        io.execute {
            val result = JSONObject()
            try {
                val wifi = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
                if (!wifi.isWifiEnabled) {
                    result.put("error", "الواي فاي مغلق. شغّله ثم أعد الفحص.")
                } else {
                    val started = runCatching { wifi.startScan() }.getOrDefault(false)
                    mainHandler.postDelayed({
                        io.execute {
                            try {
                                val entries = org.json.JSONArray()
                                val scans = wifi.scanResults.orEmpty()
                                    .filter { it.SSID.isNotBlank() }
                                    .distinctBy { it.BSSID ?: it.SSID }
                                    .sortedByDescending { it.level }
                                var crownFound = false
                                var crownNumber = ""
                                var standardFound = false
                                for (scan in scans) {
                                    val ssid = scan.SSID.trim()
                                    val rssi = scan.level
                                    val level = WifiManager.calculateSignalLevel(rssi, 5) + 1
                                    val band = when {
                                        scan.frequency in 2400..2500 -> "2.4 GHz"
                                        scan.frequency in 4900..5900 -> "5 GHz"
                                        scan.frequency >= 5925 -> "6 GHz"
                                        else -> "غير معروف"
                                    }
                                    val ap = Regex("\\(\\s*(\\d+)\\s*\\)\\s*$").find(ssid)?.groupValues?.get(1)
                                    val isCrown = ssid.contains("A::5G الكامل", ignoreCase = true)
                                    val isStandard = ssid.contains("2Gالكامل نت", ignoreCase = true)
                                    if (isCrown) { crownFound = true; if (!ap.isNullOrBlank()) crownNumber = ap }
                                    if (isStandard) standardFound = true
                                    val item = JSONObject()
                                    item.put("ssid", ssid)
                                    item.put("rssi", rssi)
                                    item.put("level", level)
                                    item.put("frequency", scan.frequency)
                                    item.put("band", band)
                                    item.put("security", when {
                                        scan.capabilities.contains("WPA3", true) -> "WPA3"
                                        scan.capabilities.contains("WPA", true) -> "WPA/WPA2"
                                        scan.capabilities.contains("WEP", true) -> "WEP"
                                        else -> "مفتوحة"
                                    })
                                    item.put("crown", isCrown)
                                    item.put("standard", isStandard)
                                    entries.put(item)
                                }
                                result.put("networks", entries)
                                result.put("count", entries.length())
                                result.put("scanStarted", started)
                                result.put("crownFound", crownFound)
                                result.put("crownNumber", crownNumber)
                                result.put("standardFound", standardFound)
                                if (entries.length() == 0) result.put("error", "لم تظهر شبكات. تأكد من تشغيل خدمة الموقع ومنح إذن الموقع، ثم أعد المحاولة.")
                                else if (!started) result.put("notice", "تم عرض آخر نتائج مسح متاحة؛ قد تكون قديمة بسبب قيود Android على تكرار المسح.")
                            } catch (e: Exception) {
                                result.put("error", "تعذر قراءة الشبكات القريبة: ${e.message ?: "تحقق من أذونات الموقع"}")
                            }
                            runOnUiThread {
                                if (!isFinishing && !isDestroyed && ::web.isInitialized) {
                                    web.evaluateJavascript("window.onNearbyWifiResult && window.onNearbyWifiResult($result)", null)
                                }
                            }
                        }
                    }, 1800L)
                }
            } catch (e: Exception) {
                result.put("error", "تعذر فحص الوايرلس: ${e.message ?: "حدث خطأ"}")
                runOnUiThread {
                    if (!isFinishing && !isDestroyed && ::web.isInitialized)
                        web.evaluateJavascript("window.onNearbyWifiResult && window.onNearbyWifiResult($result)", null)
                }
            }
            if (result.has("error")) runOnUiThread {
                if (!isFinishing && !isDestroyed && ::web.isInitialized)
                    web.evaluateJavascript("window.onNearbyWifiResult && window.onNearbyWifiResult($result)", null)
            }
        }
    }

    private fun hasUsageStatsAccess(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return false
        val ops = getSystemService(APP_OPS_SERVICE) as android.app.AppOpsManager
        @Suppress("DEPRECATION")
        return ops.checkOpNoThrow(android.app.AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) == android.app.AppOpsManager.MODE_ALLOWED
    }

    private fun applicationIconData(app: android.content.pm.ApplicationInfo): String {
        return runCatching {
            val drawable = packageManager.getApplicationIcon(app).mutate()
            val bitmap = Bitmap.createBitmap(72, 72, Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(bitmap)
            drawable.setBounds(0, 0, 72, 72)
            drawable.draw(canvas)
            val output = java.io.ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)
            bitmap.recycle()
            "data:image/png;base64," + android.util.Base64.encodeToString(output.toByteArray(), android.util.Base64.NO_WRAP)
        }.getOrDefault("")
    }

    private fun collectAppNetworkUsage(): JSONObject {
        if (!hasUsageStatsAccess()) {
            return JSONObject().put("status", "permission")
                .put("message", "يرجى السماح للتطبيق بالوصول إلى بيانات الاستخدام من إعدادات أندرويد.")
        }
        try {
            val calendar = java.util.Calendar.getInstance()
            calendar.set(java.util.Calendar.HOUR_OF_DAY, 0)
            calendar.set(java.util.Calendar.MINUTE, 0)
            calendar.set(java.util.Calendar.SECOND, 0)
            calendar.set(java.util.Calendar.MILLISECOND, 0)
            val start = calendar.timeInMillis
            val end = System.currentTimeMillis()
            val traffic = HashMap<Int, Pair<Long, Long>>()
            val manager = getSystemService(NETWORK_STATS_SERVICE) as android.app.usage.NetworkStatsManager

            // Keep the original الكامل-تحديد السرعة accounting method:
            // collect Wi-Fi and mobile traffic per application UID, excluding system UIDs.
            fun collect(networkType: Int) {
                var stats: android.app.usage.NetworkStats? = null
                try {
                    stats = manager.querySummary(networkType, null, start, end)
                    val bucket = android.app.usage.NetworkStats.Bucket()
                    while (stats.hasNextBucket()) {
                        if (!stats.getNextBucket(bucket)) break
                        val uid = bucket.uid
                        if (uid >= 10000) {
                            val previous = traffic[uid] ?: (0L to 0L)
                            traffic[uid] = (previous.first + bucket.rxBytes.coerceAtLeast(0L)) to
                                (previous.second + bucket.txBytes.coerceAtLeast(0L))
                        }
                    }
                } finally {
                    runCatching { stats?.close() }
                }
            }

            collect(ConnectivityManager.TYPE_WIFI)
            try {
                collect(ConnectivityManager.TYPE_MOBILE)
            } catch (e: Exception) {
                Log.w("AlkamelNet", "Mobile network usage query failed", e)
            }

            val apps = packageManager.getInstalledApplications(0)
                .filter { it.uid >= 10000 }
                .mapNotNull { app ->
                    val usage = traffic[app.uid] ?: return@mapNotNull null
                    val total = usage.first + usage.second
                    if (total <= 0L) return@mapNotNull null
                    Triple(app, usage, total)
                }
                .sortedByDescending { it.third }

            // Apply the same 11% once to the overall total, then distribute it
            // proportionally among the seven highest-consuming applications.
            val rawOverallTotal = apps.sumOf { it.third }
            val adjustedOverallTotal = kotlin.math.round(rawOverallTotal.toDouble() * 1.11).toLong()
            val extraBytes = (adjustedOverallTotal - rawOverallTotal).coerceAtLeast(0L)
            val displayedTotals = LongArray(apps.size) { apps[it].third }

            if (apps.isNotEmpty() && extraBytes > 0L) {
                val recipientsCount = minOf(7, apps.size)
                val recipientBytes = apps.take(recipientsCount).sumOf { it.third }
                if (recipientBytes > 0L) {
                    data class Share(val index: Int, val bytes: Long, val remainder: Double)
                    val shares = (0 until recipientsCount).map { index ->
                        val exact = extraBytes.toDouble() * apps[index].third.toDouble() / recipientBytes.toDouble()
                        val whole = kotlin.math.floor(exact).toLong()
                        displayedTotals[index] += whole
                        Share(index, whole, exact - whole.toDouble())
                    }
                    var remaining = extraBytes - shares.sumOf { it.bytes }
                    shares.sortedByDescending { it.remainder }.forEach { share ->
                        if (remaining > 0L) {
                            displayedTotals[share.index] += 1L
                            remaining--
                        }
                    }
                }
            }

            val resultApps = org.json.JSONArray()
            apps.forEachIndexed { index, item ->
                resultApps.put(JSONObject()
                    .put("name", runCatching {
                        packageManager.getApplicationLabel(item.first).toString()
                    }.getOrDefault(item.first.packageName))
                    .put("bytes", displayedTotals[index])
                    .put("icon", applicationIconData(item.first)))
            }
            return JSONObject()
                .put("status", "ok")
                .put("apps", resultApps)
                .put("totalBytes", adjustedOverallTotal)
                .put("startTime", start)
                .put("endTime", end)
        } catch (e: Exception) {
            Log.e("AlkamelNet", "App usage read failed", e)
            return JSONObject().put("status", "error").put("message", "تعذر قراءة إحصاءات التطبيقات.")
        }
    }

    private fun requestAppNetworkUsage() {
        // Read fresh Android network statistics only when the subscriber taps Refresh.
        io.execute {
            val data = collectAppNetworkUsage()
            val payload = JSONObject.quote(data.toString())
            runOnUiThread {
                if (::web.isInitialized && !isFinishing && !isDestroyed)
                    web.evaluateJavascript("if(window.onAppNetworkUsageResult)window.onAppNetworkUsageResult(JSON.parse($payload));", null)
            }
        }
    }

    private fun openUsageAccessSettings() {
        runOnUiThread {
            val packageUri = Uri.parse("package:$packageName")
            val intents = listOf(
                Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, packageUri),
                Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS),
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, packageUri)
            )
            var opened = false
            var lastError: Exception? = null
            for (settingsIntent in intents) {
                try {
                    settingsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(settingsIntent)
                    opened = true
                    break
                } catch (e: Exception) {
                    lastError = e
                    Log.w("AlkamelNet", "Unable to open usage access settings with action ${settingsIntent.action}", e)
                }
            }
            if (!opened) {
                Toast.makeText(
                    this,
                    "تعذر فتح الإعدادات تلقائياً. افتح: الإعدادات ← التطبيقات ← وصول خاص ← الوصول إلى بيانات الاستخدام، ثم فعّل شبكة الكامل.",
                    Toast.LENGTH_LONG
                ).show()
                Log.e("AlkamelNet", "All usage settings intents failed", lastError)
            } else {
                Toast.makeText(this, "فعّل السماح بالوصول إلى بيانات الاستخدام لتطبيق شبكة الكامل، ثم ارجع إلى التطبيق.", Toast.LENGTH_LONG).show()
            }
        }
    }
    private val firewallConsentRequest = 7420
    private var pendingFirewallPackages: Set<String>? = null
    private fun restoreFirewallIfNeeded() {
        if (firewallBlockedPackages().isEmpty()) return
        if (android.net.VpnService.prepare(this) == null) {
            runCatching { startFirewallService() }
                .onFailure { Log.e("AlkamelFirewall", "Unable to restore saved firewall", it) }
        }
    }
    private fun firewallPrefs() = getSharedPreferences("app_firewall", MODE_PRIVATE)
    private fun firewallBlockedPackages(): Set<String> = firewallPrefs().getStringSet("blocked_packages", emptySet())?.toSet() ?: emptySet()
    private fun setFirewallPackages(packages: Set<String>) {
        firewallPrefs().edit().putStringSet("blocked_packages", packages.toSet()).apply()
        if (packages.isEmpty()) stopService(Intent(this, AppFirewallVpnService::class.java)) else {
            val consent = android.net.VpnService.prepare(this)
            if (consent != null) { pendingFirewallPackages = packages.toSet(); startActivityForResult(consent, firewallConsentRequest) } else startFirewallService()
        }
        notifyFirewallStatus()
    }
    private fun startFirewallService() { val i = Intent(this, AppFirewallVpnService::class.java); if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i) }
    private fun notifyFirewallStatus() { if (!::web.isInitialized || isFinishing || isDestroyed) return; val count=firewallBlockedPackages().size; web.post { web.evaluateJavascript("window.onFirewallStatus && window.onFirewallStatus($count)",null) } }
    private fun firewallAppsJson(): String {
        val pm=packageManager; val blocked=firewallBlockedPackages()
        val apps=pm.getInstalledApplications(PackageManager.GET_META_DATA).filter { it.packageName != packageName && pm.getLaunchIntentForPackage(it.packageName)!=null }
            .map { a ->
                val iconData = runCatching {
                    val drawable = pm.getApplicationIcon(a)
                    val bitmap = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888)
                    val canvas = Canvas(bitmap)
                    drawable.setBounds(0, 0, 48, 48)
                    drawable.draw(canvas)
                    val bytes = java.io.ByteArrayOutputStream().use { out ->
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                        out.toByteArray()
                    }
                    "data:image/png;base64," + android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
                }.getOrDefault("")
                JSONObject().put("packageName",a.packageName)
                    .put("name",pm.getApplicationLabel(a).toString())
                    .put("icon",iconData)
                    .put("blocked",blocked.contains(a.packageName))
            }
            .sortedBy { it.optString("name").lowercase(java.util.Locale.getDefault()) }
        return org.json.JSONArray(apps).toString()
    }
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==firewallConsentRequest) { val pending=pendingFirewallPackages; pendingFirewallPackages=null
            if(resultCode==Activity.RESULT_OK && pending!=null) startFirewallService() else { firewallPrefs().edit().putStringSet("blocked_packages",emptySet()).apply(); Toast.makeText(this,"يلزم السماح باتصال VPN لتفعيل منع التطبيقات",Toast.LENGTH_LONG).show() }
            notifyFirewallStatus(); if(::web.isInitialized) web.evaluateJavascript("window.onFirewallApps && window.onFirewallApps(JSON.parse(${JSONObject.quote(firewallAppsJson())}))",null)
        }
    }
    inner class Bridge {
        @JavascriptInterface fun startChat(name: String) { startLanChat(name) }
        @JavascriptInterface fun sendChatMessage(message: String) { if (message.isNotBlank() && message.length <= 1000) sendLanPacket("message", message.trim()) }
        @JavascriptInterface fun sendChatGift(giftId: String) { if (giftId in setOf("rose", "heart", "crown", "diamond", "trophy", "fireworks")) sendLanPacket("gift", giftId) }
        @JavascriptInterface fun sendProfilePhoto(dataUrl: String) { if (dataUrl.isEmpty() || (dataUrl.length <= 3500 && dataUrl.startsWith("data:image/jpeg;base64,"))) sendLanPacket("profile_photo", dataUrl) }
        @JavascriptInterface fun sendVoiceSeatEvent(action: String, seat: Int) {
            if (action in setOf("join", "leave") && seat in 0..4) sendLanPacket("voice_seat", JSONObject().put("action", action).put("seat", seat).put("muted", false).toString())
        }
        @JavascriptInterface fun sendVoiceMessage(dataUrl: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, "الرسائل الصوتية المسجلة غير متاحة عبر LAN حالياً؛ استخدم مجلس الصوت المباشر", Toast.LENGTH_LONG).show() }
        }
        @JavascriptInterface
        fun sendPrivateChatPacket(type: String, targetId: String, requestId: String, message: String) {
            if (type in setOf("private_request", "private_response", "private_message") && targetId.length <= 64 && requestId.length <= 64 && message.length <= 1000) {
                sendPrivateLanPacket(type, targetId, requestId, message.trim())
            }
        }
        @JavascriptInterface fun openOriginalPortal() { runOnUiThread { lastHomeUrl = originalPortalUrl; web.loadUrl(originalPortalUrl) } }
        @JavascriptInterface fun openGoogleAiHome() { runOnUiThread { loadHome() } }
        @JavascriptInterface fun openVLC(streamUrl: String) { externalPlayer(streamUrl, "org.videolan.vlc") }
        @JavascriptInterface fun openMXPlayer(streamUrl: String) { externalPlayer(streamUrl, "com.mxtech.videoplayer.ad") }
        @JavascriptInterface fun showToast(message: String) {
            val safeMessage = message.take(180)
            runOnUiThread { Toast.makeText(this@MainActivity, safeMessage, Toast.LENGTH_SHORT).show() }
        }

        @JavascriptInterface fun stopChat() { stopVoiceRoom(); stopLanChat() }
        @JavascriptInterface fun joinVoiceRoom() { requestVoiceRoom() }
        @JavascriptInterface fun setVoiceMuted(muted: Boolean) { setVoiceMute(muted) }
        @JavascriptInterface fun setVoicePlaybackMuted(muted: Boolean) { setVoicePlaybackMute(muted) }
        @JavascriptInterface fun leaveVoiceRoom() { stopVoiceRoom() }

        @JavascriptInterface fun getFirewallApps() { val p=JSONObject.quote(firewallAppsJson()); runOnUiThread { if(::web.isInitialized && !isFinishing) web.evaluateJavascript("window.onFirewallApps && window.onFirewallApps(JSON.parse($p))",null) } }
        @JavascriptInterface fun setFirewallAppBlocked(packageName:String,blocked:Boolean) { if(packageName.isBlank() || packageName==this@MainActivity.packageName || packageName.length>255)return; runOnUiThread { val s=firewallBlockedPackages().toMutableSet(); if(blocked)s.add(packageName) else s.remove(packageName); setFirewallPackages(s); getFirewallApps() } }
        @JavascriptInterface fun scanNearbyWifi() { runOnUiThread { requestNearbyWifiScan() } }
        @JavascriptInterface fun getAppNetworkUsage() { requestAppNetworkUsage() }
        @JavascriptInterface fun openUsageAccessSettings() { this@MainActivity.openUsageAccessSettings() }
        @JavascriptInterface
        fun openUrl(url: String) {
            runOnUiThread {
                val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return@runOnUiThread
                if (uri.scheme == "http" && uri.host in allowedHosts) {
                    pendingPageAfterHome = when {
                        url.startsWith("http://30.30.30.30:8080/tv/") ||
                            url.startsWith("http://30.10.10.10:88/") -> "live"
                        url.startsWith("http://30.30.30.30:8096/") ||
                            url.startsWith("http://30.10.10.10/") -> "rest"
                        else -> null
                    }
                    web.loadUrl(url)
                } else Toast.makeText(this@MainActivity, "الرابط غير مسموح به داخل التطبيق", Toast.LENGTH_SHORT).show()
            }
        }

        @JavascriptInterface fun openHd() { runOnUiThread { pendingPageAfterHome = "live"; web.loadUrl("https://appassets.androidplatform.net/assets/hd/index.html") } }
        @JavascriptInterface fun home() { runOnUiThread { if (lastHomeUrl == originalPortalUrl) web.loadUrl(originalPortalUrl) else loadHome() } }

        @JavascriptInterface
        fun logout() {
            runOnUiThread {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("تسجيل الخروج")
                    .setMessage("هل تريد إنهاء جلسة حسابك في شبكة الكامل؟")
                    .setNegativeButton("إلغاء", null)
                    .setPositiveButton("تسجيل الخروج") { _, _ -> web.loadUrl("http://k.com/logout?erase-cookie=yes&var=callBack") }
                    .show()
            }
        }

        @JavascriptInterface
        fun disconnect() {
            runOnUiThread {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("قطع الاتصال")
                    .setMessage("هل تريد قطع اتصالك الحالي بالشبكة؟")
                    .setNegativeButton("إلغاء", null)
                    .setPositiveButton("قطع الاتصال") { _, _ ->
                        // Match the original portal userLogout() default: end the session
                        // without requesting erase-cookie=yes. Full logout below
                        // explicitly clears the portal cookie.
                        web.loadUrl("http://k.com/logout?var=callBack")
                    }
                    .show()
            }
        }

        @JavascriptInterface
        fun refresh() {
            if (!refreshInProgress.compareAndSet(false, true)) return
            io.execute {
                var connection: HttpURLConnection? = null
                try {
                    connection = URL("http://k.com/status?var=callBack").openConnection() as HttpURLConnection
                    connection.connectTimeout = 8000
                    connection.readTimeout = 8000
                    connection.requestMethod = "GET"
                    connection.setRequestProperty("Accept", "application/json, text/plain, */*")
                    connection.setRequestProperty("Cache-Control", "no-cache, no-store")
                    connection.setRequestProperty("Pragma", "no-cache")
                    CookieManager.getInstance().getCookie("http://k.com")?.let { connection.setRequestProperty("Cookie", it) }
                    val code = connection.responseCode
                    if (code !in 200..299) throw IllegalStateException("HTTP $code")
                    val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }.trim()
                    val json = JSONObject(body)
                    if (!json.has("logged_in")) throw IllegalStateException("Invalid status response")
                    val payload = JSONObject.quote(json.toString())
                    runOnUiThread {
                        if (::web.isInitialized && !isFinishing) web.evaluateJavascript("if(window.onStatusData){window.onStatusData(JSON.parse($payload));}", null)
                    }
                } catch (e: Exception) {
                    Log.w("AlkamelNet", "Status refresh failed", e)
                    runOnUiThread {
                        if (::web.isInitialized && !isFinishing) web.evaluateJavascript("if(typeof setQueryNotice==='function')setQueryNotice('تعذر جلب البيانات. تحقق من اتصالك بشبكة الكامل؛ لم يتم تحديث القراءات.','error');else if(document.getElementById('queryNotice'))document.getElementById('queryNotice').textContent='تعذر جلب البيانات. تحقق من اتصالك بشبكة الكامل.';", null)
                    }
                } finally {
                    connection?.disconnect()
                    refreshInProgress.set(false)
                }
            }
        }

        @JavascriptInterface
        fun runNetworkTest(planValue: String, selectedPlan: String) {
            if (selectedPlan.length > 100 || planValue.length > 40) return
            io.execute {
                val result = JSONObject()
                try {
                    val wifi = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
                    val info = runCatching { wifi.connectionInfo }.getOrNull()
                    val rawSsid = info?.ssid?.trim()?.removeSurrounding("\"")?.takeIf { it.isNotBlank() && it != "<unknown ssid>" }
                    val apNumber = rawSsid?.let { Regex("\\(\\s*(\\d+)\\s*\\)\\s*$").find(it)?.groupValues?.get(1) }
                    val rssi = info?.rssi ?: -127
                    val level = if (rssi in -100..-1) WifiManager.calculateSignalLevel(rssi, 5) else -1
                    val wifiConnected = runCatching { (getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).activeNetwork?.let { network -> (getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).getNetworkCapabilities(network)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) } == true }.getOrDefault(false)
                    result.put("wifiConnected", wifiConnected)
                    result.put("ssid", rawSsid ?: "غير متاح (قد يتطلب إذن الموقع في Android)")
                    result.put("signal", if (level >= 0) "${rssi} dBm · ${level + 1}/5" else "غير متاح")
                    result.put("apNumber", apNumber ?: "غير معروف")
                    var pingText = "تعذر القياس"
                    runCatching {
                        val started = System.nanoTime()
                        val conn = URL("https://www.google.com/generate_204").openConnection() as HttpURLConnection
                        conn.connectTimeout = 7000; conn.readTimeout = 7000; conn.requestMethod = "GET"
                        val code = conn.responseCode; conn.disconnect()
                        if (code in 200..399) pingText = "${(System.nanoTime() - started) / 1_000_000} ms"
                    }
                    result.put("ping", pingText)
                    var downloadText = "تعذر القياس"
                    var measuredMbps = 0.0
                    runCatching {
                        val conn = URL("https://speed.cloudflare.com/__down?bytes=3000000").openConnection() as HttpURLConnection
                        conn.connectTimeout = 10000; conn.readTimeout = 15000
                        conn.setRequestProperty("Cache-Control", "no-cache")
                        val started = System.nanoTime(); var total = 0L
                        conn.inputStream.use { input ->
                            val buffer = ByteArray(16384)
                            while (true) { val count = input.read(buffer); if (count < 0) break; total += count }
                        }
                        val seconds = (System.nanoTime() - started) / 1_000_000_000.0
                        conn.disconnect()
                        if (total > 0 && seconds > 0.0) {
                            measuredMbps = total * 8.0 / seconds / 1_000_000.0
                            downloadText = String.format(java.util.Locale.US, "%.2f Mbps", measuredMbps)
                        }
                    }
                    result.put("download", downloadText)
                    val downloadPart = planValue.substringAfter('/', planValue).trim()
                    val rateMatch = Regex("(\\d+(?:[.,]\\d+)?)([kKmM]?)").find(downloadPart)
                    val rawRate = rateMatch?.groupValues?.get(1)?.replace(',', '.')?.toDoubleOrNull()
                    val unit = rateMatch?.groupValues?.get(2)?.lowercase()
                    val expected = when (unit) { "k" -> rawRate?.div(1000.0); "m" -> rawRate; else -> rawRate }
                    val planResult = when {
                        expected == null || expected <= 0 -> "تعذرت قراءة سرعة الباقة: $selectedPlan"
                        measuredMbps <= 0 -> "لم تكتمل مقارنة السرعة"
                        measuredMbps >= expected * 0.8 -> "السرعة قريبة من الباقة أو أعلى منها ($selectedPlan)"
                        else -> "السرعة المقاسة أقل من سرعة الباقة ($selectedPlan)"
                    }
                    result.put("planResult", planResult)
                    if (pingText == "تعذر القياس" || downloadText == "تعذر القياس") result.put("error", "تعذر إكمال بعض القياسات؛ تحقق من اتصال الإنترنت. اختبار التنزيل يستهلك نحو 3 ميجابايت.")
                } catch (e: Exception) {
                    result.put("error", "حدث خطأ أثناء الاختبار: ${e.message ?: "تعذر الوصول للشبكة"}")
                }
                runOnUiThread {
                    if (!isFinishing && !isDestroyed && ::web.isInitialized) {
                        web.evaluateJavascript("window.onNetworkTestResult && window.onNetworkTestResult(${result})", null)
                    }
                }
            }
        }
        @JavascriptInterface
        fun applyNetworkSetting(speed: String, googleFlag: String?) {
            runOnUiThread {
                if (!speed.matches(Regex("[A-Za-z0-9./]+"))) {
                    Toast.makeText(this@MainActivity, "قيمة السرعة غير صالحة", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                if (googleFlag != null && googleFlag !in setOf("*yes**", "*no**")) {
                    Toast.makeText(this@MainActivity, "قيمة إعداد جوجل غير صالحة", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                pendingCommand = speed to googleFlag
                if (commandWeb == null) initializeCommandWebView()
                runPendingCommand()
            }
        }

        @JavascriptInterface
        fun externalPlayer(url: String, packageName: String) {
            runOnUiThread {
                // Only allow the bundled HD stream and the two player packages
                // exposed by the app UI; never pass arbitrary URLs to other apps.
                if (url != "http://10.10.10.10:8888/live/index.m3u8" ||
                    packageName !in setOf("org.videolan.vlc", "com.mxtech.videoplayer.ad")) {
                    Toast.makeText(this@MainActivity, "طلب تشغيل غير مسموح به", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                try {
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(Uri.parse(url), "application/vnd.apple.mpegurl")
                        setPackage(packageName)
                    }
                    startActivity(intent)
                } catch (_: ActivityNotFoundException) {
                    Toast.makeText(this@MainActivity, "المشغل المطلوب غير مثبت على الجهاز", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Log.e("AlkamelNet", "External player launch failed", e)
                    Toast.makeText(this@MainActivity, "تعذر فتح المشغل الخارجي", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun hideCustomView() {
        val active = customView ?: return
        customViewContainer.removeView(active)
        customViewContainer.visibility = View.GONE
        web.visibility = View.VISIBLE
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (customView != null) { hideCustomView(); return }
        if (!::web.isInitialized) {
            super.onBackPressed()
            return
        }
        val currentUrl = web.url.orEmpty()
        val returnPage = when {
            currentUrl.startsWith("http://30.30.30.30:8080/tv/") ||
                currentUrl.startsWith("http://30.10.10.10:88/") ||
                currentUrl.startsWith("https://appassets.androidplatform.net/assets/hd/") -> "live"
            currentUrl.startsWith("http://30.30.30.30:8096/") ||
                currentUrl.startsWith("http://30.10.10.10/") -> "rest"
            else -> null
        }
        if (returnPage != null) {
            if (lastHomeUrl == originalPortalUrl) {
                pendingPageAfterHome = returnPage
                web.loadUrl(originalPortalUrl)
            } else {
                pendingPageAfterHome = returnPage
                loadHome()
            }
            return
        }

        // Always delegate portal navigation to the page-level back handler.
        // This keeps support sub-pages inside the support menu even when the
        // WebView is serving the bundled page through its data/local fallback URL.
        web.evaluateJavascript(
            "if(typeof window.appBack==='function'){window.appBack();'handled';}else{'reload';}"
        ) { result ->
            if (result == null || result.contains("reload")) {
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) {
                        if (lastHomeUrl == originalPortalUrl) web.loadUrl(originalPortalUrl) else loadHome()
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        captureChatNotificationIntent(intent)
        openPendingChatNotificationRoute()
    }

    private fun captureChatNotificationIntent(source: Intent?) {
        if (source?.getBooleanExtra("com.alkamel.network.OPEN_CHAT_NOTIFICATION", false) != true) return
        pendingNotificationChatRoute = true
        pendingNotificationChatKind = source.getStringExtra("chat_kind").orEmpty().ifBlank { "message" }
        pendingNotificationPeerId = source.getStringExtra("target").orEmpty()
        pendingNotificationPeerName = source.getStringExtra("name").orEmpty()
        pendingNotificationRequestId = source.getStringExtra("request_id").orEmpty()
    }

    private fun openPendingChatNotificationRoute() {
        if (!pendingNotificationChatRoute || !::web.isInitialized || isFinishing || isDestroyed) return
        val kind = JSONObject.quote(pendingNotificationChatKind)
        val peer = JSONObject.quote(pendingNotificationPeerId)
        val name = JSONObject.quote(pendingNotificationPeerName)
        val request = JSONObject.quote(pendingNotificationRequestId)
        web.post {
            if (!pendingNotificationChatRoute || isFinishing || isDestroyed) return@post
            web.evaluateJavascript("window.openChatFromNotification && window.openChatFromNotification(" + kind + "," + peer + "," + name + "," + request + ");", null)
            pendingNotificationChatRoute = false
        }
    }

    override fun onResume() {
        super.onResume()
        appInForeground = true
        if (::web.isInitialized) {
            web.onResume()
            web.resumeTimers()
            val pausedFor = if (backgroundedAtMs > 0L) System.currentTimeMillis() - backgroundedAtMs else 0L
            val current = web.url.orEmpty()
            if (pausedFor >= 2500L) {
                // LAN players often retain dead HTTP sockets after Android suspends WebView.
                if (isExternalServiceUrl(current)) {
                    Log.i("AlkamelNet", "Reconnecting service after background pause (${pausedFor}ms): $current")
                    web.post { if (!isFinishing && !isDestroyed) web.loadUrl(current) }
                } else {
                    // A LAN service page may retain a dead HTTP/WebView session after
                    // Android backgrounds the app. Return to the bundled home page and
                    // restore the relevant section, so every service can be opened again.
                    val returnPage = when {
                        current.startsWith("http://30.30.30.30:8080/tv/") ||
                            current.startsWith("http://30.10.10.10:88/") ||
                            current.startsWith("https://appassets.androidplatform.net/assets/hd/") -> "live"
                        current.startsWith("http://30.30.30.30:8096/") ||
                            current.startsWith("http://30.10.10.10/") -> "rest"
                        else -> null
                    }
                    if (returnPage != null) pendingPageAfterHome = returnPage
                    verifyPrivateNetworkAccess {
                        if (returnPage != null || (!current.startsWith(homeUrl) && !current.startsWith("data:"))) {
                            loadHome()
                        } else recoverHomeAfterResume()
                    }
                }
                // The hidden portal WebView can also keep stale sockets/cookies after resume.
                commandWeb?.let { hidden ->
                    commandPageReady = false
                    commandAttemptInProgress = false
                    hidden.post {
                        if (!isFinishing && !isDestroyed) {
                            hidden.stopLoading()
                            hidden.loadUrl("http://k.com/")
                        }
                    }
                }
            }
            backgroundedAtMs = 0L
        }
        commandWeb?.onResume()
        if (requestNotificationsOnResume) {
            requestNotificationsOnResume = false
            requestNotificationPermission()
        }
    }

    /**
     * Verify that the home page JavaScript and click-navigation functions are alive
     * after returning from background. Recover a broken WebView instead of leaving
     * the user with an interface that looks active but ignores every section tap.
     */
    private fun recoverHomeAfterResume() {
        val token = ++resumeRecoveryToken
        var callbackReceived = false
        web.evaluateJavascript(
            "(function(){try{var legacy=typeof showPage==='function'&&document.querySelector('.page');var modern=document.querySelector('#root')&&document.body&&document.body.innerText.length>0;return legacy||modern?'ok':'broken';}catch(e){return 'broken';}})()"
        ) { result ->
            if (token != resumeRecoveryToken || isFinishing || isDestroyed) return@evaluateJavascript
            callbackReceived = true
            if (result?.contains("ok") == true) {
                showLoading(false)
                hideError()
                web.evaluateJavascript(
                    "window.dispatchEvent(new Event('focus'));if(typeof window.appOnResume==='function')window.appOnResume();",
                    null
                )
                Log.i("AlkamelNet", "Home WebView passed resume health check")
            } else {
                Log.w("AlkamelNet", "Home WebView failed resume health check; reloading home")
                if (lastHomeUrl == originalPortalUrl) web.loadUrl(originalPortalUrl) else loadHome()
            }
        }
        mainHandler.postDelayed({
            if (token == resumeRecoveryToken && !callbackReceived) {
                if (!isFinishing && !isDestroyed) {
                    Log.e("AlkamelNet", "Home WebView did not answer resume health check; recreating Activity")
                    recreate()
                }
            }
        }, 3500L)
    }

    private fun isExternalServiceUrl(url: String): Boolean =
        url.startsWith("http://30.30.30.30:8096/") ||
        url.startsWith("http://30.10.10.10/") ||
        url.startsWith("http://30.30.30.30:8080/tv/") ||
        url.startsWith("http://30.10.10.10:88/") ||
        url.startsWith("https://appassets.androidplatform.net/assets/hd/")

    override fun onStop() {
        // onPause also runs for permission prompts and transient system dialogs.
        // Record the background transition only once the Activity is no longer visible.
        backgroundedAtMs = System.currentTimeMillis()
        super.onStop()
    }

    override fun onPause() {
        appInForeground = false
        if (::web.isInitialized) {
            web.onPause()
            web.pauseTimers()
        }
        commandWeb?.onPause()
        commandWeb?.pauseTimers()
        super.onPause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (::web.isInitialized) web.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        // Release Activity-owned LAN sockets and workers on every destruction path.
        stopVoiceRoom()
        stopLanChat()
        io.shutdownNow()
        voiceExecutor.shutdownNow()
        voiceReceiveExecutor.shutdownNow()
        chatExecutor.shutdownNow()
        chatSendExecutor.shutdownNow()
        networkGuard.shutdownNow()
        if (::web.isInitialized) {
            if (customView != null) hideCustomView()
            web.removeJavascriptInterface("AndroidBridge")
            web.removeJavascriptInterface("Android")
            web.stopLoading()
            web.loadUrl("about:blank")
            web.destroy()
        }
        commandWeb?.apply { stopLoading(); loadUrl("about:blank"); destroy() }
        commandWeb = null
        super.onDestroy()
    }
}
