# الكامل نت 3.0.0 — المشروع المدمج المستقل

هذا مشروع Android مستقل جديد. لا يستبدل ولا يغيّر مصدر الإصدار 1.9.3.

## هوية النسخة
- اسم التطبيق: الكامل نت
- الإصدار: **3.0.0**
- `versionCode`: **300**
- `applicationId`: `com.mohammedkamel.alkamelnet.portal2026.v300`
- `namespace`: `com.alkamel.network`
- الحد الأدنى: Android 7.0 (API 24)
- الهدف: Android 15 (API 35)
- Java/Kotlin target: 17

## طريقة الدمج
1. واجهة Google AI هي واجهة التشغيل الرئيسية داخل `app/src/main/assets/googleai/`.
2. مشروع شبكة الكامل الأصلي 1.9.3 محفوظ في التطبيق مع صفحته وأصوله الأصلية، ويُفتح من زر **بوابة المشترك** داخل واجهة Google AI.
3. جميع وظائف Android الأصلية من 1.9.3 محفوظة في `MainActivity` والخدمات التابعة لها: دردشة LAN، المحادثات الخاصة، الهدايا، الصور الشخصية، غرفة الصوت، الإشعارات، خدمات الخلفية، جدار التطبيقات، فحص Wi-Fi، واختبار الشبكة وإعداداتها.
4. تم توفير واجهة JavaScript باسم `Android` لتوافق مشغل Google AI مع VLC وMX Player، مع الاحتفاظ بواجهة `AndroidBridge` الأصلية.
5. تمت إضافة عرض الفيديو بملء الشاشة ودعم العودة بين واجهتي Google AI وبوابة المشترك.
6. ملفات مشروع Google AI الأصلية (بما فيها MainActivity وWebAppInterface وموارد Android) محفوظة كما وردت في `integration/google-ai-original/` للمراجعة، ولا تُبنى كنسخة ثانية متعارضة.

## التحقق
شغّل:
```bash
python3 scripts/validate_merged_project.py
```
هذا الفحص يتحقق من وجود المكونات والملفات وبيانات الإصدار، لكنه **ليس بديلاً عن بناء Gradle أو الاختبار على هاتف فعلي**.

## البناء
افتح مجلد `Alkamel-Net-3.0.0` في Android Studio ثم نفّذ Gradle Sync وBuild APK.
أو ادفع محتويات هذا المجلد إلى جذر فرع GitHub الذي تريد بناءه؛ ملف GitHub Actions في `.github/workflows/android-build.yml` يبني APK Debug ويرفعه كـ Artifact عند push أو عبر `workflow_dispatch`.

## ملاحظة
لم يتم الادعاء بأن APK قد بُني أو اختُبر على جهاز؛ تسليم هذه الحزمة هو تسليم مصدر الدمج. يجب انتظار نتيجة GitHub Actions ثم إجراء اختبار تشغيل فعلي قبل اعتماد الإصدار.
