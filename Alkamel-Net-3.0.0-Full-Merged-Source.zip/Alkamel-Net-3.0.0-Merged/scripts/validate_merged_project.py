#!/usr/bin/env python3
from pathlib import Path
import re, sys, zipfile

ROOT = Path(__file__).resolve().parents[1]
checks = []
def check(label, condition):
    checks.append((label, bool(condition)))

gradle = (ROOT/"app/build.gradle.kts").read_text(encoding="utf-8")
main = (ROOT/"app/src/main/java/com/alkamel/network/MainActivity.kt").read_text(encoding="utf-8")
manifest = (ROOT/"app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
check("versionName is 3.0.0", 'versionName = "3.0.0"' in gradle)
check("versionCode is 300", "versionCode = 300" in gradle)
check("independent applicationId", 'applicationId = "com.mohammedkamel.alkamelnet.portal2026.v300"' in gradle)
check("Google AI React entry point", (ROOT/"app/src/main/assets/googleai/index.html").is_file())
check("Google AI JavaScript bundle", any((ROOT/"app/src/main/assets/googleai/assets").glob("*.js")))
check("Google AI stylesheet", any((ROOT/"app/src/main/assets/googleai/assets").glob("*.css")))
check("Original 1.9.3 portal preserved", (ROOT/"app/src/main/assets/home.html").is_file())
check("Original portal assets preserved", (ROOT/"app/src/main/assets/original/index.html").is_file())
check("Original chat/voice native implementation preserved", "fun startLanChat" in main and "fun startVoiceRoom" in main)
check("Original private chat and gifts preserved", "sendPrivateLanPacket" in main and 'sendLanPacket("gift"' in main)
check("Firewall service preserved", (ROOT/"app/src/main/java/com/alkamel/network/AppFirewallVpnService.kt").is_file())
check("Background service preserved", (ROOT/"app/src/main/java/com/alkamel/network/ChatKeepAliveService.kt").is_file())
check("Google AI Android bridge compatibility", '"Android")' in main and "fun openVLC" in main and "fun openMXPlayer" in main)
check("Switch to original portal available", "openOriginalPortal" in main)
check("Switch back to Google AI home available", "openGoogleAiHome" in main)
check("Fullscreen video support merged", "onShowCustomView" in main and "onHideCustomView" in main)
check("Boot receiver registered", ".FirewallBootReceiver" in manifest)
check("Google AI original native sources retained", (ROOT/"integration/google-ai-original/app/src/main/java/com/alkamel/net/MainActivity.kt").is_file())
check("Google AI original WebAppInterface retained", (ROOT/"integration/google-ai-original/app/src/main/java/com/alkamel/net/WebAppInterface.kt").is_file())

for label, ok in checks:
    print(("PASS" if ok else "FAIL") + " - " + label)
failed = [label for label, ok in checks if not ok]
print(f"\n{len(checks)-len(failed)}/{len(checks)} checks passed.")
sys.exit(1 if failed else 0)
