package com.alkamel.net

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.webkit.JavascriptInterface
import android.widget.Toast

class WebAppInterface(private val context: Context) {

    @JavascriptInterface
    fun showToast(message: String) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    @JavascriptInterface
    fun openVLC(streamUrl: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.setPackage("org.videolan.vlc")
            intent.setDataAndType(Uri.parse(streamUrl), "video/*")
            intent.putExtra("title", "الكامل-نت HD")
            context.startActivity(intent)
        } catch (e: Exception) {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(streamUrl))
            context.startActivity(Intent.createChooser(intent, "اختر مشغل الفيديو"))
        }
    }

    @JavascriptInterface
    fun openMXPlayer(streamUrl: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.setPackage("com.mxtech.videoplayer.ad")
            intent.setDataAndType(Uri.parse(streamUrl), "video/*")
            intent.putExtra("title", "الكامل-نت HD")
            context.startActivity(intent)
        } catch (e: Exception) {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(streamUrl))
            context.startActivity(Intent.createChooser(intent, "اختر مشغل الفيديو"))
        }
    }
}
