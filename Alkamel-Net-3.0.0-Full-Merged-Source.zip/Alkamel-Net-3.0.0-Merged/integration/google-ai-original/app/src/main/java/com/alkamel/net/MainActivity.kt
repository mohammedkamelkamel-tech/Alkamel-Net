package com.alkamel.net

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.*
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.webkit.WebViewAssetLoader
import java.io.InputStream

/**
 * MainActivity for الكامل-نت (Alkamel Net)
 * Fixes white screen via WebViewAssetLoader & explicit HTTPS origin domain.
 */
class MainActivity : Activity() {

    companion object {
        private const val TAG = "AlkamelNet"
        private const val ASSET_DOMAIN = "appassets.androidplatform.net"
        private const val HOME_URL = "https://$ASSET_DOMAIN/assets/www/index.html"
        private const val FALLBACK_URL = "file:///android_asset/www/index.html"
    }

    private lateinit var webView: WebView
    private lateinit var loadingLayout: LinearLayout
    private lateinit var errorLayout: LinearLayout
    private lateinit var errorDescription: TextView
    private lateinit var btnRetry: Button
    private lateinit var customViewContainer: FrameLayout
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private lateinit var assetLoader: WebViewAssetLoader

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        Log.d(TAG, "Alkamel-Net MainActivity starting...")

        webView = findViewById(R.id.webView)
        loadingLayout = findViewById(R.id.loadingLayout)
        errorLayout = findViewById(R.id.errorLayout)
        errorDescription = findViewById(R.id.errorDescription)
        btnRetry = findViewById(R.id.btnRetry)
        customViewContainer = findViewById(R.id.customViewContainer)

        btnRetry.setOnClickListener {
            Log.d(TAG, "User clicked retry. Reloading $HOME_URL")
            errorLayout.visibility = View.GONE
            loadingLayout.visibility = View.VISIBLE
            webView.loadUrl(HOME_URL)
        }

        assetLoader = WebViewAssetLoader.Builder()
            .setDomain(ASSET_DOMAIN)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        setupWebView()

        Log.d(TAG, "Loading entry point: $HOME_URL")
        webView.loadUrl(HOME_URL)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.allowFileAccessFromFileURLs = true
        settings.allowUniversalAccessFromFileURLs = true
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        settings.cacheMode = WebSettings.LOAD_DEFAULT

        CookieManager.getInstance().setAcceptCookie(true)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        }

        webView.addJavascriptInterface(WebAppInterface(this), "AndroidApp")

        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                consoleMessage?.let {
                    Log.i(TAG + "JS", "${it.message()} -- line ${it.lineNumber()} of ${it.sourceId()}")
                }
                return true
            }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                customViewContainer.addView(view, ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                ))
                customViewContainer.visibility = View.VISIBLE
                webView.visibility = View.GONE
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }

            override fun onHideCustomView() {
                if (customView == null) return
                customViewContainer.removeView(customView)
                customViewContainer.visibility = View.GONE
                webView.visibility = View.VISIBLE
                customView = null
                customViewCallback?.onCustomViewHidden()
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val uri = request?.url ?: return null
                val path = uri.path ?: ""
                
                // Map home.html to index.html if requested
                if (path.endsWith("home.html")) {
                    try {
                        val isStream: InputStream = assets.open("www/index.html")
                        val headers = mapOf("Access-Control-Allow-Origin" to "*")
                        return WebResourceResponse("text/html", "UTF-8", 200, "OK", headers, isStream)
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed mapping home.html", e)
                    }
                }

                return assetLoader.shouldInterceptRequest(uri)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                Log.d(TAG, "Page started loading: $url")
                loadingLayout.visibility = View.VISIBLE
                errorLayout.visibility = View.GONE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                Log.d(TAG, "Page finished loading successfully: $url")
                loadingLayout.visibility = View.GONE
                errorLayout.visibility = View.GONE
                webView.visibility = View.VISIBLE
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                val failingUrl = request?.url?.toString() ?: ""
                val isMainFrame = request?.isForMainFrame ?: false
                Log.e(TAG, "onReceivedError: failingUrl=$failingUrl, isMainFrame=$isMainFrame")

                if (isMainFrame) {
                    if (failingUrl.startsWith("https://$ASSET_DOMAIN")) {
                        Log.w(TAG, "AssetLoader failed, trying fallback: $FALLBACK_URL")
                        webView.loadUrl(FALLBACK_URL)
                        return
                    }
                    loadingLayout.visibility = View.GONE
                    errorLayout.visibility = View.VISIBLE
                    errorDescription.text = "تعذر تحميل واجهة التطبيق ($failingUrl)"
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("vlc://")) {
                    openWithVLC(url.substring(6))
                    return true
                }
                if (url.startsWith("intent:")) {
                    try {
                        val intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                        startActivity(intent)
                        return true
                    } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "المشغل الخارجي غير متوفر", Toast.LENGTH_SHORT).show()
                    }
                }
                return false
            }
        }
    }

    fun openWithVLC(streamUrl: String) {
        val uri = Uri.parse(streamUrl)
        val vlcIntent = Intent(Intent.ACTION_VIEW).apply {
            setPackage("org.videolan.vlc")
            setDataAndTypeAndNormalize(uri, "video/*")
            putExtra("title", "الكامل-نت - بث مباشر HD")
        }
        try {
            startActivity(vlcIntent)
        } catch (e: Exception) {
            val fallback = Intent(Intent.ACTION_VIEW, uri)
            startActivity(Intent.createChooser(fallback, "تشغيل عبر مشغل فيديو"))
        }
    }

    override fun onBackPressed() {
        if (customView != null) {
            (webView.webChromeClient as? WebChromeClient)?.onHideCustomView()
        } else if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
